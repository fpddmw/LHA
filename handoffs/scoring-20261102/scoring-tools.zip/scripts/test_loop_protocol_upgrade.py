"""Zero-provider contracts for the next online task protocol."""
import copy
import json
from pathlib import Path
import sys
import tempfile
import threading
import time
import unittest
ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT/"src"),str(ROOT/"scripts")]
from planner_harness import accounting as a
from planner_harness import resources as r,continuation as c
from planner_harness.common import load


class ProtocolTests(unittest.TestCase):
    def state(self,n=5,used=0,fraction=0):
        now = time.time()
        s = {"created_at":"2026-11-02T00:00:00Z","config":{"max_generations":n},"jobs":{},"videos":{},
             "submitted_generation_ids":[],"online_clock":{"started_unix":now-3600*fraction,"deadline_unix":now+3600*(1-fraction)}}
        r.configure(s);c.configure(s)
        for i in range(used):
            key = str(i);s["jobs"][key]={"kind":"generate"};s["submitted_generation_ids"].append(key)
        return s

    def test_n_and_time_phase_do_not_disclose_limits(self):
        for n in (1,3,5,9):
            for fraction,stage in ((0,"exploration"),(.41,"continuation"),(.61,"deliberate"),(.81,"strong")):
                s=self.state(n,fraction=fraction);v=c.view(s)
                self.assertEqual(v["stage"],stage)
                self.assertEqual(set(v),{"stage","budget_awareness","justification_required","continuation_questions","generation_available"})
            s=self.state(n,used=n)
            self.assertFalse(c.view(s)["generation_available"])
            r.check_wall(s) # N locks generation; reading/delivery still admitted.
        self.assertEqual(c.phase(self.state(9,used=6)),"deliberate")

    def test_prepared_jobs_do_not_count_and_legacy_caps_are_metering(self):
        s=self.state(1);s["jobs"]["not-dispatched"]={"kind":"generate"}
        self.assertEqual(c.usage(s)["submitted_render_requests"],0)
        self.assertIsNone(s["config"]["max_turns"])
        with tempfile.TemporaryDirectory() as tmp:
            for i in range(101):r.reserve(tmp,str(i),s["config"]["resource_policy"],50000)
            ledger=load(Path(tmp)/"resource-ledger.json")
            self.assertEqual(len(ledger["calls"]),101)
            self.assertGreater(sum(v["charged_tokens"] for v in ledger["calls"].values()),4000000)

    def binding(self,tmp,n=9,wall=3600):
        p={"version":a.VERSION,"mode":"offline","max_call_seconds":.01,
           "online_task_budget":{"version":"online-task-v2","lanes":["full","none"],"max_generations":n,"wall_seconds":wall}}
        root=a.install(Path(tmp)/"accounting",p)
        b=a.scope(root,"sample__short","full");a.start_task(b,wall_seconds=wall)
        return b

    def test_metered_calls_and_per_method_clock_are_independent(self):
        with tempfile.TemporaryDirectory() as tmp:
            b=self.binding(tmp)
            for i in range(101):a.invoke(b,str(i),"model","fixture",lambda:{},tokens=50000)
            other=a.scope(b["root"],b["topic"],"none")
            clock=a.start_task(other)
            self.assertGreater(clock["deadline_unix"],time.time()+3590)
            self.assertEqual(a.summary(b["root"])["reserved_or_settled_totals"]["model_calls"],101)
            a.invoke(b,"longer-than-old-call-timeout","model","fixture",lambda:time.sleep(.03))

    def test_deadline_cancels_only_owned_process_and_blocks_late_submission(self):
        import subprocess
        unrelated=subprocess.Popen([sys.executable,"-c","import time;time.sleep(5)"])
        try:
            with tempfile.TemporaryDirectory() as tmp:
                b=self.binding(tmp,wall=1);root=Path(b["root"])
                # Existing clock is durable; force a small fixture deadline using its first start.
                other=a.scope(root,"short-task","full");a.start_task(other,wall_seconds=1)
                launched=[]
                def call():
                    child,remove=a.launch_owned([sys.executable,"-c","import time;time.sleep(5)"],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
                    launched.append(child)
                    try:child.process.communicate()
                    finally:remove()
                    return {"late":True}
                with self.assertRaises(r.ResourceExhausted):a.invoke(other,"owned","model","fixture",call)
                self.assertIsNotNone(launched[0].process.poll())
                self.assertIsNone(unrelated.poll())
                self.assertTrue(a.start_task(other,wall_seconds=1)["frozen_unix"])
                with self.assertRaises(r.ResourceExhausted):a.invoke(other,"new","model","fixture",lambda:self.fail("late submit"))
                end=time.monotonic()+2
                while a.active(root) and time.monotonic()<end:time.sleep(.01)
                record=a.operation(other,"owned")
                self.assertIn(record["status"],{"late_complete","failed_unknown_cost"})
                self.assertEqual(a.summary(root)["reserved_or_settled_totals"]["model_calls"],1)
        finally:unrelated.terminate();unrelated.wait()

    def test_generation_failures_occupy_and_before_submit_does_not(self):
        with tempfile.TemporaryDirectory() as tmp:
            b=self.binding(tmp,1)
            with self.assertRaises(ValueError):a.invoke(b,"invalid","render","fixture",lambda:None,before_submit=lambda:(_ for _ in ()).throw(ValueError("validation")))
            with self.assertRaises(ValueError):a.invoke(b,"failed","render","fixture",lambda:(_ for _ in ()).throw(ValueError("execution")))
            with self.assertRaises(a.SubmissionRefused):a.invoke(b,"extra","render","fixture",lambda:None)
            self.assertEqual(a.summary(b["root"])["reserved_or_settled_totals"]["render_requests"],1)


class IntegrationTests(unittest.TestCase):
    def test_full_renderer_call_receipt_without_gpu(self):
        from server_runtime.renderers import PersistentRenderer
        from types import SimpleNamespace
        from unittest.mock import patch
        with tempfile.TemporaryDirectory() as tmp:
            folder=Path(tmp);native=folder/'native.mp4'
            renderer=object.__new__(PersistentRenderer)
            renderer.root=ROOT;renderer.prefix='prefix ';renderer.clean=lambda x:x
            renderer.kwargs=lambda x:{};renderer.cli=None
            renderer.assets={'model_revision':'fixture-model','code_revision':'fixture-code'}
            renderer.config={'asset_manifest_sha256':'fixture-assets'}
            renderer.prepare=lambda job,directory:({'frames':1,'fps':1},[0],4)
            renderer.pipeline=lambda *args,**kwargs:Path(kwargs['output_path']).write_bytes(b'fixture-video')
            job={'payload':{'input':{'path':str(folder/'input.mp4'),'sha256':'input-hash'},'prompt':'Make blue.',
                 'renderer':{'seed':1,'output':{'frames':1,'fps':1},'generation':{}}}}
            with patch.dict(sys.modules,{'run_prompt_probe':SimpleNamespace(inspect_video=lambda path:{'frames':1,'fps':1})}):
                value=renderer(job,folder)
            self.assertEqual(value['execution']['preflight'],'passed')
            self.assertEqual(value['execution']['input_sha256'],'input-hash')
            self.assertEqual(value['execution']['token_count'],4)
            self.assertTrue(native.is_file())

    def test_knowledge_problem_routes_snapshot_and_none_scope(self):
        from planner_harness.creative_knowledge import CreativeKnowledge
        full=CreativeKnowledge(ROOT,experience_mode='full');none=CreativeKnowledge(ROOT,experience_mode='none')
        for identity in ('planning-resources','observation-diagnosis','generation-input'):
            self.assertTrue(full.read(identity)['links'])
            with self.assertRaises(ValueError):none.read(identity)
        matches=full.search('Which input can recover a lost face?')['matches']
        self.assertTrue(any(m.get('recommendation') and m.get('renderers') for m in matches))
        self.assertFalse(any(m.get('id','').startswith(('EX-','EV-')) for m in none.search('lost face')['matches']))
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'snapshot.json';full.freeze(path)
            self.assertEqual(CreativeKnowledge(ROOT,path).search('lost face'),full.search('lost face'))

    def run_record(self,root):
        from planner_harness.common import save,sha
        from planner_harness.creative_knowledge import CreativeKnowledge
        run=root/'run';run.mkdir()
        state={'config':{'workflow':'creative_loop_v1','execution':{'experience_mode':'none'}},'status':'budget_exhausted',
               'request':{'text':'Make the scene blue.'},'final':{'outcome':'incomplete'},'events':[{'event_id':'event-0001'}]}
        save(run/'state.json',state);CreativeKnowledge(ROOT,experience_mode='none').freeze(run/'knowledge-snapshot.json')
        call=run/'calls/event-0001';save(call/'input.json',{'system_prompt':'role','user_text':'task','images':[]})
        save(call/'transport/input.json',{'system_prompt':'role','user_text':'task'})
        (call/'response.txt').write_text('{"action":"note","arguments":{"text":"Task evidence"}}')
        save(call/'transport/returned.json',{'sha256':sha(call/'response.txt')})
        return run

    def test_test_only_idempotent_batch_gate_and_failure_isolation(self):
        from planner_harness import maintenance as m
        from planner_harness.common import sha
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);run=self.run_record(root);before=sha(run/'state.json')
            self.assertFalse(m.eligible(run,'train'));self.assertFalse(m.eligible(run,'validation'));self.assertTrue(m.eligible(run,'test'))
            self.assertIsNone(m.enqueue(ROOT,root,run,split='train',topic='t',method='none',batch_sha256='b'))
            identity=m.enqueue(ROOT,root,run,split='test',topic='t',method='none',batch_sha256='b')
            self.assertEqual(identity,m.enqueue(ROOT,root,run,split='test',topic='t',method='none',batch_sha256='b'))
            with self.assertRaises(ValueError):m.drain(ROOT,root,{'enabled':True})
            self.assertEqual(m.drain(ROOT,root,{'enabled':False})['status'],'disabled')
            batch={'sha256':'b','topics':[{'id':'t'}],'arms':['none']}
            with self.assertRaises(ValueError):m.seal_batch(root,batch,[])
            m.seal_batch(root,batch,[{'topic':'t','method':'none','status':'failed'}])
            class Broken:
                model='gpt-6.1-sol';reasoning_effort='high'
                def predict_text(self,**kwargs):raise ValueError('fixture permanent failure')
            result=m.drain(ROOT,root,{'enabled':True},model_factory=Broken)
            self.assertEqual(result['jobs'][0]['status'],'failed')
            self.assertEqual(before,sha(run/'state.json'))

    def test_maintenance_retains_loaded_skill_and_cross_task_revision(self):
        from planner_harness import maintenance as m
        from planner_harness.common import sha
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);run=self.run_record(root);before=sha(run/'state.json')
            identity=m.enqueue(ROOT,root,run,split='test',topic='t',method='none',batch_sha256='b')
            m.seal_batch(root,{'sha256':'b','topics':[{'id':'t'}],'arms':['none']},[{'topic':'t','method':'none','status':'ready'}])
            class Contributor:
                model='gpt-6.1-sol';reasoning_effort='high'
                def __init__(self):self.inputs=[]
                def predict_text(self,**kwargs):
                    self.inputs.append(json.loads(kwargs['user_text']))
                    n=len(self.inputs)
                    if n==1:return json.dumps({'action':'skill','arguments':{'id':'lha-experience-use-review'}})
                    if n==2:return json.dumps({'action':'read','arguments':{'source':'run','id':'state'}})
                    self.assertions=all('lha-experience-use-review' in x.get('loaded_skills',{}) for x in self.inputs[1:])
                    return json.dumps({'action':'contribute','arguments':{'text':'Keep the required relation visible when evaluating an incomplete event. The saved record leaves the unseen transition unresolved.'}})
            clients=[]
            def factory():
                c=Contributor();clients.append(c);return c
            result=m.drain(ROOT,root,model_factory=factory)
            self.assertEqual(result['jobs'][0]['status'],'complete')
            self.assertTrue(all('lha-experience-use-review' in c.inputs[-1].get('loaded_skills',{}) for c in clients))
            bundle=Path(result['candidate_bundle']);self.assertTrue((bundle.parent/'candidate-revision.md').exists())
            self.assertEqual(before,sha(run/'state.json'))

    def test_frozen_recovery_retains_state_and_never_reopens(self):
        from planner_harness.common import save,sha
        from planner_harness.recovery import recover_tool
        with tempfile.TemporaryDirectory() as tmp:
            run=Path(tmp);state={'config':{'workflow':'creative_loop_v1'},'status':'budget_exhausted','final':{'video':'v1'},
                'online_clock':{'started_unix':time.time()-3601,'deadline_unix':time.time()-1},'jobs':{'j':{'kind':'generate','mode':'live','sha256':'request'}}}
            save(run/'state.json',state);before=sha(run/'state.json')
            record=recover_tool(run,'j','not-executed','Operator evidence after deadline')
            self.assertFalse(record['task_result_changed']);self.assertEqual(before,sha(run/'state.json'))
            with self.assertRaises(ValueError):recover_tool(run,'j','retry-review','Do not reopen')
            self.assertEqual(before,sha(run/'state.json'))


if __name__ == "__main__":unittest.main()
