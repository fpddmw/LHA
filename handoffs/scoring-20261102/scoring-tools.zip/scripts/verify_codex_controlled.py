"""Capture a pinned real Codex client's loopback mock-provider request, with no paid calls."""
import argparse,base64,hashlib,json,os,sys,tempfile,threading,zlib
from pathlib import Path
from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))


def normalize(value):
    if isinstance(value,list):return [normalize(x) for x in value]
    if isinstance(value,dict):return {k:normalize(v) for k,v in value.items() if not (k=='id' and value.get('type') in {'message','additional_tools'})}
    return value


def verify(executable,output,adversarial=False):
    output=Path(output).resolve();output.mkdir(parents=True,exist_ok=True)
    captures=[]
    class Handler(BaseHTTPRequestHandler):
        def log_message(self,*args):pass
        def do_GET(self):
            self.send_response(200);self.send_header('Content-Type','application/json');self.end_headers();self.wfile.write(b'{"data":[]}')
        def do_POST(self):
            raw=self.rfile.read(int(self.headers['Content-Length']))
            if self.headers.get('Content-Encoding')=='gzip':
                import gzip
                raw=gzip.decompress(raw)
            if self.headers.get('Content-Encoding')=='zstd':
                import zstandard
                raw=zstandard.ZstdDecompressor().decompress(raw)
            body=json.loads(raw);captures.append(body)
            self.send_response(200);self.send_header('Content-Type','text/event-stream');self.send_header('Connection','close');self.end_headers()
            if adversarial and len(captures)==1:
                call={'id':'tool_fixture','type':'custom_tool_call','call_id':'call_fixture','namespace':'functions','name':'exec','input':'text("LHA_TOOL_SENTINEL")'}
                events=[('response.created',{'response':{'id':'resp_tool','status':'in_progress','output':[]}}),
                    ('response.output_item.done',{'output_index':0,'item':call}),
                    ('response.completed',{'response':{'id':'resp_tool','status':'completed','output':[call],'usage':{'input_tokens':10,'output_tokens':4,'total_tokens':14}}})]
                for event,data in events:self.wfile.write(('event: '+event+'\ndata: '+json.dumps({'type':event,**data})+'\n\n').encode())
                self.wfile.flush();return
            message={'id':'msg_fixture','type':'message','role':'assistant','status':'completed','content':[{'type':'output_text','text':'{"fixture":true}','annotations':[]}]}
            events=[('response.created',{'response':{'id':'resp_fixture','object':'response','status':'in_progress','output':[]}}),
                ('response.output_item.added',{'output_index':0,'item':{**message,'status':'in_progress','content':[]}}),
                ('response.output_text.delta',{'item_id':'msg_fixture','output_index':0,'content_index':0,'delta':'{"fixture":true}'}),
                ('response.output_item.done',{'output_index':0,'item':message}),
                ('response.completed',{'response':{'id':'resp_fixture','object':'response','status':'completed','model':body['model'],'output':[message],'usage':{'input_tokens':10,'output_tokens':4,'total_tokens':14}}})]
            for event,data in events:self.wfile.write(('event: '+event+'\ndata: '+json.dumps({'type':event,**data})+'\n\n').encode())
            self.wfile.flush()
    server=ThreadingHTTPServer(('127.0.0.1',0),Handler)
    thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
    try:
        from PIL import Image
        from vlm.codex_vlm import CodexVisionModel
        image=output/'input.png';Image.new('RGB',(1300,700),(40,80,130)).save(image)
        client=CodexVisionModel(model='gpt-6.1-sol',reasoning_effort='high');client.executable=str(Path(executable).resolve());client.attempts=1;client.lha_audit_directory=str(output/'audit')
        client._test_allow_tools=adversarial
        client._test_extra_overrides=['model_provider="lha_mock"','model_providers.lha_mock.name="LHA loopback no paid provider"',
            'model_providers.lha_mock.base_url="http://127.0.0.1:'+str(server.server_address[1])+'/v1"',
            'model_providers.lha_mock.wire_api="responses"','model_providers.lha_mock.requires_openai_auth=false','features.responses_websockets=false','features.responses_websockets_v2=false']
        answer=client.predict_text(system_prompt='LHA_ROLE_ONLY_SENTINEL. Return a JSON object.',user_text='LHA_USER_ONLY_SENTINEL',image_paths=[str(image)])
        (output/'wire.json').write_text(json.dumps(captures,indent=2))
        assert (adversarial or len(captures)==1) and answer=='{"fixture":true}'
        body=captures[0]
        serialized=json.dumps(body)
        assert 'LHA_ROLE_ONLY_SENTINEL' in serialized and 'LHA_USER_ONLY_SENTINEL' in serialized
        assert 'AGENTS.md instructions' not in serialized and 'Available skills' not in serialized and '<multi_agent_role>' not in serialized
        images=[]
        def walk(x):
            if isinstance(x,dict):
                if x.get('type')=='input_image':images.append(x)
                for v in x.values():walk(v)
            elif isinstance(x,list):
                for v in x:walk(v)
        walk(body)
        audit=json.loads((output/'audit/client-assembly.json').read_text())
        assert len(images)==1
        assert 'could not read' not in serialized.lower() and serialized.count('LHA_USER_ONLY_SENTINEL')==1
        wire_images=[hashlib.sha256(base64.b64decode(x['image_url'].split(',',1)[1])).hexdigest() for x in images]
        assert wire_images==[x['sha256'] for x in audit['images']]
        result={'status':'passed','runtime':client.runtime_identity(),'provider_requests':len(captures),'paid_requests':0,
                'image_sha256_match':True,'wire_tools':[x.get('name',x.get('type')) for x in body.get('tools',[])],
                'debug_exec_same_input':normalize(json.loads((output/'audit/client-input.json').read_text()))==normalize(body['input']),
                'embedded_tool_names':[ns.get('name')+'.'+t.get('name') for item in body.get('input',[]) if item.get('type')=='additional_tools' for ns in item.get('tools',[]) for t in ns.get('tools',[])],
                'adversarial':adversarial,'sentinel_in_later_request':any(any(i.get('type')=='custom_tool_call_output' and 'LHA_TOOL_SENTINEL' in json.dumps(i.get('output')) for i in b.get('input',[])) for b in captures[1:]),
                'client_execution':client.last_client_audit,
                'debug_scope':'Preflight input list is recorded separately; wire.json is the actual exec mock-provider request.',
                'server_scope':'Only the real client request to the local mock is observed; production server assembly remains unknown.'}
        (output/'verification.json').write_text(json.dumps(result,indent=2));return result
    finally:server.shutdown();server.server_close()


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--executable',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--adversarial',action='store_true');args=p.parse_args()
    os.environ['LOW_HIGH_CODEX_BIN']=str(args.executable.resolve())
    print(json.dumps(verify(args.executable,args.output,args.adversarial)))

if __name__=='__main__':main()
