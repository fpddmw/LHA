"""Prepare/check selected current sources and methods; execute on authorized assets."""
import argparse
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=["prepare", "preflight", "provider-preflight", "recover-direct", "run", "status"])
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--host-config", type=Path)
    parser.add_argument("--budget-config",type=Path,help="Explicit batch/topic resource limits; choose quoted allowance or count_limits_only")
    parser.add_argument("--judge", choices=["glm5.3flash", "sonnet-5.5high"], default="glm5.3flash")
    parser.add_argument("--device")
    parser.add_argument("--topic")
    parser.add_argument("--reason")
    parser.add_argument("--receipt", type=Path)
    parser.add_argument("--not-executed", action="store_true")
    parser.add_argument("--split", nargs="+", choices=["train", "validation", "test"], default=["train", "validation", "test"])
    parser.add_argument("--prompt-form", nargs="+", choices=["short", "long"], default=["short", "long"])
    parser.add_argument("--method", nargs="+", choices=["direct", "direct-best-of-n", "planner-once", "pe", "full", "none"], default=["direct", "full", "none"])
    parser.add_argument("--seed-start", type=int, default=42)
    parser.add_argument("--seed-step", type=int, default=1)
    parser.add_argument("--max-generations", type=int, default=5)
    parser.add_argument("--max-turns", type=int, default=None, help="Deprecated metering field; online tasks stop at time/generation policy")
    parser.add_argument("--best-of-n", type=int)
    parser.add_argument("--results-root", type=Path, default=ROOT / "out/benchmark_results")
    parser.add_argument("--resource-policy", type=Path)
    parser.add_argument("--planner-config", type=Path, help="Frozen Planner model/effort; current approved policy is gpt-6.1-sol/high")
    args = parser.parse_args()
    from planner_harness.common import load, save
    from experiments.creative_benchmark import prepare, verify_batch
    from experiments.creative_benchmark import run
    from experiments.preflight import local_preflight, host_preflight, provider_preflight
    host = load(args.host_config) if args.host_config else None
    if args.command == "prepare":
        result = prepare(ROOT, args.output, splits=args.split, prompt_forms=args.prompt_form, methods=args.method,
            seed_start=args.seed_start, seed_step=args.seed_step, max_generations=args.max_generations,
            max_turns=args.max_turns, best_of_n=args.best_of_n, results_root=args.results_root,
            resource_policy=load(args.resource_policy) if args.resource_policy else None,
            planner=load(args.planner_config) if args.planner_config else None)
        print(json.dumps({"status": "prepared", "topics": len(result["topics"]), "arms": result["arms"], "model_calls": 0, "gpu_jobs": 0}))
    elif args.command == "preflight":
        batch = verify_batch(ROOT, args.output)
        if batch.get("schema") == "lha-unified-benchmark-v1":
            from experiments.unified_benchmark import preflight
            result = preflight(ROOT, args.output, host)
        else:
            result = {"local": local_preflight(ROOT, args.output), "host": host_preflight(ROOT, host, execute=bool(host))}
        save(args.output / "preflight.json", result)
        print(json.dumps(result))
    elif args.command == "provider-preflight":
        from planner_harness.accounting import install,scope,bind
        if not args.budget_config:parser.error("Real provider preflight requires --budget-config")
        budget_root = install(args.output/"accounting",load(args.budget_config),require_live=True,required_quotes=("model:"+args.judge+"/"+("high" if args.judge=="sonnet-5.5high" else "none"),))
        bind(args.output,scope(budget_root,"provider-preflight"))
        from planner_harness.supervisor import maybe_supervise_cli
        if maybe_supervise_cli(args.output,[__file__,*sys.argv[1:]]):return
        print(json.dumps(provider_preflight(args.output, name=args.judge)))
    elif args.command == "recover-direct":
        if args.device is None or not args.topic or not args.reason:
            parser.error("Direct recovery requires --device, --topic and --reason")
        from experiments.recovery import recover_direct
        print(json.dumps(recover_direct(args.output, args.device, args.topic, args.reason,
                                       receipt=args.receipt, not_executed=args.not_executed)))
    elif args.command == "run":
        if host is None:
            parser.error("Use --host-config for explicitly opened devices and verified assets")
        if args.budget_config:host["budget"] = load(args.budget_config)
        from planner_harness.accounting import install,validate_cohort
        batch=verify_batch(ROOT,args.output)
        if batch.get("schema") == "lha-unified-benchmark-v1":
            from experiments.unified_benchmark import policy as unified_policy
            policy=unified_policy(batch, host.get("budget"))
        else:
            policy=validate_cohort(host.get("budget"),max_generations=batch["max_generations"],topics=batch["topics"])
        install(args.output/"accounting",policy,require_live=True)
        from planner_harness.supervisor import maybe_supervise_cli
        if maybe_supervise_cli(args.output,[__file__,*sys.argv[1:]]):return
        result = run(ROOT, args.output, host)
        print(json.dumps({"status": result["status"], "topics": len(result["topics"])}))
    else:
        print(json.dumps(load(args.output / "checkpoint.json") if (args.output / "checkpoint.json").exists() else {"status": "prepared_not_started"}))


if __name__ == "__main__":
    from planner_harness.supervisor import cli_entry
    cli_entry(main)
