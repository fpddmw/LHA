"""Reviewed execution dependencies; broad audit inventories live outside cohort identity.

Add a dependency here when the current creative path starts executing it. Model-visible
knowledge/manuals are additionally enumerated by CreativeKnowledge, including assets.
"""
from pathlib import Path

from .common import sha

MODULES = {
    "planner_harness": "__init__ common lock runner video event_observation knowledge creative_knowledge creative creative_actions context working_memory resources accounting supervisor owned_process recovery integrity json_output model_call report_call execution automatic_review continuation delivery delivery_review experience_usage creative_report report protocol_sources lineage",
    "critic_harness": "__init__ adapter one_shot event_review evidence",
    "server_runtime": "__init__ queue engine service renderers media_cache lifecycle",
    "evaluation": "__init__ creative protocol registry task_spec task_metrics final_suite low_high pairwise temporal low_high_summary media features",
    "vlm": "__init__ codex_vlm litellm_vlm",
    "experiments": "__init__ creative_benchmark unified_benchmark results preflight recovery",
}
SCRIPTS = ("scripts/run_creative_benchmark.py", "scripts/creative_benchmark_schedule.py",
           "scripts/run_creative_judge.py", "scripts/run_low_high_eval.py", "scripts/benchmark_results.py", "scripts/accounting_worker.py", "scripts/run_bernini_benchmark.py", "scripts/run_planner_worker.py",
           "scripts/deploy/run_prompt_probe.py", "configs/creative-loop-v1.json")


def protocol_inventory(root):
    root = Path(root)
    names = [f"src/{package}/{module}.py" for package, modules in MODULES.items() for module in modules.split()]
    names.extend(SCRIPTS)
    return {name:sha(root / name) for name in sorted(names)}


def audit_inventory(root):
    root = Path(root)
    return {p.relative_to(root).as_posix():sha(p) for p in sorted((root / "src").rglob("*"))
            if p.is_file() and p.suffix in {".py", ".md"}}
