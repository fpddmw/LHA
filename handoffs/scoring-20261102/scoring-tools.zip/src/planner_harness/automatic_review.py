"""One durable online review after each successful creative generation."""
import copy
from .common import load
from .execution import immutable, signature


def validate_focus(value, state):
    if value is None:
        value = {}
    if isinstance(value, str):
        value = {"focus": value}
    if not isinstance(value, dict) or set(value) - {"focus", "extra_checks", "events", "compare_to"}:
        raise ValueError("review_focus is text or focus/extra_checks/events/compare_to")
    focus = value.get("focus", "")
    checks = value.get("extra_checks", [])
    if not isinstance(focus, str) or not isinstance(checks, list) or any(not isinstance(c,str) or not c.strip() for c in checks):
        raise ValueError("Review focus/checks must be text")
    from critic_harness.one_shot import validate_focus as neutral
    from critic_harness.event_review import validate_events
    neutral(focus, checks)
    events = validate_events(value.get("events", []))
    comparison = value.get("compare_to")
    if comparison is not None and (not isinstance(comparison, str) or comparison not in state['videos']):
        raise ValueError("Comparison must identify an existing video")
    return copy.deepcopy({"focus":focus,"extra_checks":checks,"events":events,"compare_to":comparison})


def enqueue(harness, candidate, generation):
    from .execution import request_job
    folder = harness.output / 'jobs' / generation['id']
    focus = load(folder / 'review-focus.json')
    if signature(focus) != generation.get('review_focus_sha256'):
        raise ValueError('Signed review focus changed')
    expected = {'generation_sha256':generation['sha256'], 'candidate':candidate,
                'candidate_sha256':harness.state['videos'][candidate]['sha256'], 'focus_sha256':signature(focus)}
    immutable(folder / 'automatic-review.json', expected)
    result = request_job(harness, 'critique', {'video':candidate, **focus},
                         generation['id'] + '-automatic', internal=True)
    if result.get('status') not in {'pending','complete'}:
        raise ValueError('Automatic review requires reconciliation of its original request')
    harness.state['videos'][candidate]['automatic_review'] = result.get('job_id') or result.get('feedback_id')
    return result
