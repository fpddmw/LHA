"""Factual spent resources and non-semantic continuation questions; operator policy stays private."""
from __future__ import annotations

import copy
import math

from .common import load, sha
from .execution import immutable, signature
from .resources import MAX_GENERATIONS

VERSION = 'creative-continuation-v3'
QUESTIONS = [
    'Which retained candidate currently seems most suitable for delivery, and what unresolved issue makes you choose to continue?',
    'What will this attempt change or establish, and why use this input video? State plainly if it is resampling rather than a new realization.',
    'Why is the expected benefit worth another generation instead of entering delivery confirmation now?',
]
PRESSURE = {
    'exploration':'This task operates under a limited budget. Use the available resources deliberately while developing and evaluating your proposal.',
    'continuation':'Before spending resources on another generation, answer the continuation questions using the actual candidates, previous prompts and observed results.',
    'deliberate':'Further generation warrants a deliberate choice under the limited budget. Reserve it for an important unresolved part of the task. Explain why it is preferable to reviewing and delivering a retained candidate, and what this attempt will change or establish.',
    'strong':'Exercise strong restraint before spending more on generation. Prefer reviewing and confirming a suitable retained candidate. If you continue, explain the consequential gap and the concrete value of this attempt using the actual results.',
    'frozen':'Generation resources are exhausted. Inspect and compare retained candidates, use review as needed, and complete delivery confirmation for a suitable result. If none is suitable, retain a provisional candidate and report the unresolved outcome.',
}


def configure(state, supplied=None):
    resource_limit = state['config'].get('resource_policy', {}).get('max_generations', MAX_GENERATIONS)
    policy = {'version': VERSION, 'hard_generation_limit': resource_limit,
              'phase_fractions': [.4, .6, .8]}
    supplied = copy.deepcopy(supplied or {})
    if set(supplied) - set(policy):
        raise ValueError('Unknown operator continuation policy setting')
    policy.update(supplied)
    if policy['version'] != VERSION or policy['phase_fractions'] != [.4, .6, .8]:
        raise ValueError('Use the approved fractional continuation schedule')
    explicit = policy['hard_generation_limit']
    if type(explicit) is not int or explicit < 1 or explicit != resource_limit:
        raise ValueError('Conflicting operator generation limits')
    state['config']['continuation_policy'] = policy
    state['config']['max_generations'] = None
    return policy


def usage(state):
    generated = {v.get('job_id'):v for k,v in state['videos'].items() if k!='source' and not v.get('imported')}
    requests = {k:j for k,j in state.get('jobs',{}).items() if j['kind']=='generate' and (state['config'].get('resource_policy',{}).get('version') != 'creative-resources-v2' or k in state.get('submitted_generation_ids',[]))}
    outcomes = state.get('render_outcomes',{})
    failures = [k for k,v in outcomes.items() if k in requests and v['status']=='failed' and not v.get('uncertain')]
    uncertain = {k for k,v in state.get('unresolved_jobs',{}).items() if k in requests}
    uncertain.update(k for k,v in outcomes.items() if k in requests and v.get('uncertain'))
    times = []
    for video in generated.values():
        value = video.get('execution',{}).get('generation_seconds')
        if isinstance(value,(int,float)) and not isinstance(value,bool) and math.isfinite(value) and value>=0:
            times.append(value)
    for key in failures:
        value = outcomes[key].get('generation_seconds')
        if isinstance(value,(int,float)) and not isinstance(value,bool) and math.isfinite(value) and value>=0:
            times.append(value)
    return {'generated_candidates':len(generated),'submitted_render_requests':len(requests),
            'failed_render_attempts':len(failures),'uncertain_render_attempts':len(uncertain),
            'pending_or_uncollected_render_requests':max(0,len(requests)-len(generated)-len(failures)-len(uncertain)),
            'known_rendering_elapsed_seconds':sum(times),'render_cost_records_missing':len(generated)+len(failures)+len(uncertain)-len(times),
            'elapsed_time_scope':'Known rendering wall time from receipts; failed/uncertain costs may be unknown. This is not exact GPU compute time or monetary cost.'}


def phase(state):
    policy = state['config']['continuation_policy']
    n = usage(state)['submitted_render_requests']
    if n >= policy['hard_generation_limit']:
        return 'frozen'
    from .resources import elapsed
    p = max(n / policy['hard_generation_limit'], elapsed(state) / state['config']['resource_policy']['max_wall_seconds'])
    return 'exploration' if p < .4 else 'continuation' if p < .6 else 'deliberate' if p < .8 else 'strong'



def view(state):
    policy = state['config']['continuation_policy']
    facts = usage(state)
    available = not state.get('unresolved_jobs') and facts['submitted_render_requests'] < policy['hard_generation_limit']
    required = available and phase(state) != 'exploration'
    return {'stage': phase(state), 'budget_awareness': PRESSURE[phase(state)],
            'justification_required': required, 'continuation_questions': copy.deepcopy(QUESTIONS) if required else [],
            'generation_available': available}


def record_input(harness, event_id, call_dir):
    saved = load(call_dir/'input.json')
    import json
    actual = json.loads(saved['user_text']).get('continuation')
    if not isinstance(actual,dict) or set(actual) != set(view(harness.state)):
        raise ValueError('Saved continuation prompt has an unexpected visible surface')
    record = {'event_id':event_id,'model_input_sha256':sha(call_dir/'input.json'),
              'policy':copy.deepcopy(harness.state['config']['continuation_policy']),
              'stage':actual['stage'],'trigger_state':usage(harness.state),'visible':actual}
    immutable(call_dir/'continuation-policy.json',record)


def authorize(state, args, event_id):
    existing = state.get('generation_decisions',{}).get(event_id+'-generate')
    if existing:
        if existing['arguments']!=args:
            raise ValueError('Recovered generation explanation or arguments changed')
        return None
    visible = view(state)
    if not visible['generation_available']:
        return {'status':'generation_unavailable','message':'Additional generation is unavailable under the current resource policy. Observation, reading, review and delivery confirmation remain available.',
                'continuation':visible}
    explanation = args.get('justification')
    if explanation is not None and not isinstance(explanation,str):
        raise ValueError('justification must be free text')
    if visible['justification_required'] and (explanation is None or not explanation.strip()):
        return {'status':'justification_required','message':'Answer the continuation questions in the justification field together with the actual prompt and input video. No render was submitted.',
                'continuation':visible}
    return None


def record_dispatch(harness, job, args, event_id):
    state = harness.state
    key = job['id']
    record = {'event_id':event_id,'job_id':key,'request_sha256':job['sha256'],
              'arguments':copy.deepcopy(args),'justification':args.get('justification'),
              'policy_version':VERSION,'stage':phase(state),'visible':view(state),
              'input_id':job['payload']['input_id'],'input_sha256':job['payload']['input']['sha256'],
              'prompt':job['payload']['prompt'],'prompt_sha256':signature({'text':job['payload']['prompt']}),
              'model_input_path':str(harness.output/'calls'/event_id/'input.json')}
    prior = state.setdefault('generation_decisions',{}).get(key)
    if prior:
        if prior['arguments']!=args or prior['request_sha256']!=job['sha256']:
            raise ValueError('Recovered generation decision changed')
        return
    # Capture the pre-dispatch view: adding the signed job has not yet spent its slot here.
    immutable(harness.output/'jobs'/key/'continuation.json',record)
    state['generation_decisions'][key] = record


def record_outcome(state, job, response):
    if job['kind']!='generate':
        return
    execution = response.get('payload',{}).get('execution',{})
    state.setdefault('render_outcomes',{})[job['id']] = {
        'status':response['status'],'uncertain':bool(response.get('outcome_unknown')),
        'generation_seconds':execution.get('generation_seconds'),'request_sha256':job['sha256']}


def index(run, state):
    """Passive operator navigation, never a model-side usefulness grade."""
    run = str(run)
    return {'policy_version':VERSION,'scope':'Raw continuation explanations and actual outcomes; no usefulness grading or causal attribution.',
            'spent_resources':usage(state),'generations':[{
                **copy.deepcopy(record),'request_path':run+'/jobs/'+key+'/request.json',
                'response_path':run+'/jobs/'+key+'/response.json',
                'outcome':copy.deepcopy(state.get('render_outcomes',{}).get(key)),
                'candidate_ids':[i for i,v in state['videos'].items() if v.get('job_id')==key]}
                for key,record in state.get('generation_decisions',{}).items()]}
