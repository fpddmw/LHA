"""Test-only, post-batch Planner contributions. Candidate revisions never activate here."""
from __future__ import annotations
import copy
import json
from pathlib import Path
import time
from .common import load,save,sha,stamp,page
from .execution import immutable,signature
from .lock import RunLock

VERSION="lha-post-task-maintenance-v1"
SKILLS=("lha-experience-analysis","lha-experience-use-review","lha-experience-curation")
DEFAULTS={"enabled":True,"wall_seconds":1800,"model_calls":32,"tokens":2000000,"attempts":2,
          "automatic_phase":"after_batch_settlement","publish":False}
PROMPT="""You are the task's post-task Planner, contributing to the next Planner's professional knowledge.
The online result is already frozen. Use the three explicitly available Skills as needed;
a single useful contribution may combine analysis, use review and curation. Read actual
records and the knowledge version this task could see. A none task may describe only
its actual exposure; it may propose a new insight without pretending to have read full-scope entries.
Lead with a useful judgment and its conditions, then evidence, counterexamples and an
exact improvement when useful. Question your own decisions, Critic and old guidance.
Keep successes, failures and exceptions. Explain which decision useful guidance helped;
for disagreement suggest a concrete revision. Prefer improving an existing explanation.
Ordinary concise prose is sufficient. Do not provide private reasoning. No increment
is an acceptable conclusion. Do not render, score, send messages or publish.
Return one JSON action: skill {id}; browse {id}; search {query}; read {source:run|knowledge,id,
start_line?,start_char?,max_chars?}; view_image {ids:list of image IDs}; note {text}; contribute {text}. Arguments are under arguments.
The runtime attaches exact run, knowledge-version and event references automatically.
"""


def configuration(value=None):
    cfg={**DEFAULTS,**(value or {})}
    if set(cfg)!=set(DEFAULTS) or type(cfg['enabled']) is not bool or cfg['publish'] is not False or cfg['automatic_phase']!='after_batch_settlement':
        raise ValueError('Maintenance is a separate post-batch candidate workflow')
    for name in ('wall_seconds','model_calls','tokens','attempts'):
        if type(cfg[name]) is not int or cfg[name]<1:raise ValueError('Finite maintenance allowances required')
    return cfg


def eligible(run,split):
    run=Path(run)
    if split!='test' or not (run/'state.json').is_file():return False
    state=load(run/'state.json')
    if state.get('config',{}).get('workflow') not in {'creative_loop_v1','single_planner_trace'} or not state.get('final'):return False
    if state.get('status') in {'running','waiting_tool','needs_reconciliation','interrupted'}:return False
    # A real returned Planner request/answer, not invented Direct self-reflection.
    for path in [*(run/'calls').glob('*/input.json'),*(run/'call').glob('input.json')]:
        returned=path.parent/('returned.json' if path.parent.name=='call' else 'transport/returned.json')
        answer=path.parent/'response.txt'
        if answer.is_file() and returned.is_file() and load(returned).get('sha256')==sha(answer):return True
    return False


def enqueue(root, batch_output, run, *, split, topic, method, batch_sha256):
    """Idempotent after fixed settlement; no model, dataset write or activation."""
    run,batch_output=Path(run).resolve(),Path(batch_output).resolve()
    if not eligible(run,split):return None
    state=load(run/'state.json')
    identity=signature({'run':str(run),'batch_sha256':batch_sha256})
    directory=batch_output/'maintenance/jobs'/identity
    if (directory/'job.json').exists():
        existing=load(directory/'job.json')
        if existing['run_state_sha256']!=sha(run/'state.json') or existing['knowledge_snapshot_sha256']!=sha(run/'knowledge-snapshot.json'):
            raise ValueError('Original settled maintenance task changed')
        return identity
    body={'version':VERSION,'run':str(run),'run_state_sha256':sha(run/'state.json'),
          'knowledge_snapshot_sha256':sha(run/'knowledge-snapshot.json'),'batch_sha256':batch_sha256,
          'split':split,'topic':topic,'method':method,'settlement':copy.deepcopy(state['final']),
          'experience_mode':state['config']['execution'].get('experience_mode'),
          'events':[e['event_id'] for e in state.get('events',[])],
          'entry_versions':{r['id']:{k:r.get(k) for k in ('version','sha256')} for r in load(run/'knowledge-snapshot.json').get('curated_catalog',{}).get('entries',[])},
          'skills':{name:{'path':str(Path(root)/'.agents/skills'/name/'SKILL.md'),
                    'text':(Path(root)/'.agents/skills'/name/'SKILL.md').read_text(),
                    'sha256':sha(Path(root)/'.agents/skills'/name/'SKILL.md')} for name in SKILLS}}
    identity=signature({k:body[k] for k in ('run','batch_sha256')})
    directory=batch_output/'maintenance/jobs'/identity
    immutable(directory/'job.json',{**body,'id':identity})
    if not (directory/'status.json').exists():save(directory/'status.json',{'status':'queued','attempts':0})
    return identity


def seal_batch(output,batch,positions):
    """Default maintenance admission requires every online position settled."""
    output=Path(output)
    expected={(t['id'],m) for t in batch['topics'] for m in batch['arms']}
    actual={(r['topic'],r['method']) for r in positions}
    if expected!=actual or any(r['status']=='execution_unknown' for r in positions):
        raise ValueError('Default maintenance waits for complete online batch settlement')
    immutable(output/'maintenance/batch-settled.json',{'batch_sha256':batch['sha256'],
        'positions':[{'topic':r['topic'],'method':r['method'],'sha256':signature(r)} for r in positions]})


def _execute(root,folder,job,cfg,model):
    from .creative_knowledge import CreativeKnowledge
    from .model_call import call_text
    from .json_output import decode_object
    from . import accounting
    run=Path(job['run'])
    if sha(run/'state.json')!=job['run_state_sha256'] or sha(run/'knowledge-snapshot.json')!=job['knowledge_snapshot_sha256']:
        raise ValueError('Frozen task/knowledge changed before maintenance')
    knowledge=CreativeKnowledge(root,run/'knowledge-snapshot.json')
    files={'state':run/'state.json','knowledge-snapshot':run/'knowledge-snapshot.json'}
    for identity,path in job.get('additional_sources',{}).items():files[identity]=Path(path)
    for path in sorted([*(run/'calls').glob('*/*'),*(run/'call').glob('*')]):
        if path.name in {'input.json','response.txt','experience-exposure.json','continuation-policy.json'}:
            files[path.relative_to(run).as_posix()]=path
    image_catalog={}
    for call in [*(run/'calls').glob('*/input.json'),*(run/'call').glob('input.json')]:
        saved=load(call)
        for number,row in enumerate(saved.get('images',[])):
            if isinstance(row,str):continue
            if row.get('path') and row.get('sha256'):
                identity=call.relative_to(run).as_posix()+':image-'+str(number+1)
                image_catalog[identity]={k:row[k] for k in ('path','sha256','video_id','timestamp_seconds','observation_id') if k in row}
    image_focus=[]
    source_index={identity:{'sha256':sha(path),'characters':path.stat().st_size} for identity,path in files.items()}
    policy={'version':accounting.VERSION,'mode':'live' if getattr(model,'requires_live_budget',False) else 'offline',
            'cost_control':'count_limits_only','max_call_seconds':cfg['wall_seconds'],
            'batch':{**accounting.LIMITS,'model_calls':cfg['model_calls'],'tokens':cfg['tokens'],'wall_seconds':cfg['wall_seconds']},
            'topic':{**accounting.LIMITS,'model_calls':cfg['model_calls'],'tokens':cfg['tokens'],'wall_seconds':cfg['wall_seconds']},
            'lanes':['independent'],'allocations':{'independent':{**accounting.LIMITS,'model_calls':cfg['model_calls'],'tokens':cfg['tokens'],'wall_seconds':cfg['wall_seconds']}}}
    budget=accounting.install(folder/'accounting',policy,require_live=bool(getattr(model,'requires_live_budget',False)))
    model=accounting.attach(model,accounting.scope(budget,job['id']))
    deadline=time.time()+cfg['wall_seconds']
    result={'job':{k:job[k] for k in ('id','topic','method','split','settlement','experience_mode','entry_versions')},
            'skills':[{"id":name,"description":job['skills'][name]['text'].split('description:',1)[1].split('---',1)[0].strip()} for name in SKILLS],
            'run_sources':source_index,'image_catalog':image_catalog,'knowledge_entrances':knowledge.overview()}
    loaded_skills={};reading_cache=[];notes=''
    task_identity=copy.deepcopy(result['job'])
    for number in range(cfg['model_calls']):
        if time.time()>=deadline:raise TimeoutError('Maintenance time allowance exhausted')
        for identity in image_focus:
            if sha(image_catalog[identity]['path'])!=image_catalog[identity]['sha256']:raise ValueError('Original Planner image changed')
        raw=call_text(folder/'calls'/f'{number+1:04d}',model,PROMPT,json.dumps(result,ensure_ascii=False),[image_catalog[i]['path'] for i in image_focus],attempts=1)
        action=decode_object(raw);kind=action.get('action');args=action.get('arguments',{})
        try:
            if kind=='skill':
                loaded_skills[args['id']]=job['skills'][args['id']]['text']
                result={'skill':args['id'],'text':loaded_skills[args['id']]}
            elif kind=='browse':result=knowledge.browse(args.get('id','map'))
            elif kind=='search':result=knowledge.search(args['query'])
            elif kind=='read' and args.get('source')=='knowledge':result=knowledge.read(args['id'],args.get('start_line',1),start_char=args.get('start_char',0),max_chars=min(8000,args.get('max_chars',6000)))
            elif kind=='read' and args.get('source')=='run':
                path=files[args['id']]
                if sha(path)!=source_index[args['id']]['sha256']:raise ValueError('Original run source changed')
                result=page(path.read_text(),args.get('start_line',1),max_chars=min(8000,args.get('max_chars',6000)),start_char=args.get('start_char',0),split_long_lines=True)
            elif kind=='view_image':
                identities=args['ids']
                if not isinstance(identities,list) or not 1<=len(identities)<=8 or any(i not in image_catalog for i in identities):raise ValueError('Choose 1 to 8 original Planner image IDs')
                image_focus=list(dict.fromkeys(identities))
                result={'attached_images':[{'id':i,**image_catalog[i]} for i in image_focus],
                        'scope':'Existing images actually available to the original Planner; new visual claims are limited to these images. Saved Critic findings remain attributed.'}
            elif kind=='note':
                notes=args['text']
                if not isinstance(notes,str) or len(notes)>12000:raise ValueError('Keep a concise maintenance working note')
                result={'saved':True}
            elif kind=='contribute':
                text=args['text']
                if not isinstance(text,str) or not text.strip():raise ValueError('Use concise professional prose or state no increment')
                contribution={'version':VERSION,'job_id':job['id'],'text':text,'run':job['run'],
                    'run_state_sha256':job['run_state_sha256'],'knowledge_snapshot_sha256':job['knowledge_snapshot_sha256'],
                    'entry_versions':job['entry_versions'],'event_refs':job['events'],
                    'visibility':job['experience_mode'],'source_index':source_index,'model_call':number+1,
                    'activation':'candidate_only_requires_user_review'}
                immutable(folder/'contribution.json',contribution)
                (folder/'contribution.md').write_text(text+'\n')
                return contribution
            else:raise ValueError('Choose an available maintenance action')
        except (ValueError,KeyError,TypeError) as exc:result={'error':str(exc),'scope':'No render, score or publication was submitted'}
        if kind in {'read','search','browse'}:
            reading_cache.append({'action':action,'result':copy.deepcopy(result)})
            while reading_cache and len(json.dumps(reading_cache,ensure_ascii=False))>24000:reading_cache.pop(0)
        result={'current_result':result,'task':task_identity,'original_request':load(run/'state.json')['request']['text'],
                'knowledge_mode':job['experience_mode'],'loaded_skills':loaded_skills,'retained_reading':reading_cache,
                'notes':notes,'available_skills':list(SKILLS),'run_sources':source_index,'image_catalog':image_catalog,'attached_images':image_focus,
                'archive_scope':'Older exact pages remain available through read; only the bounded cache is omitted.'}
    raise RuntimeError('Maintenance call allowance exhausted')


def drain(root,output,config=None,*,model_factory=None):
    cfg=configuration(config);output=Path(output)
    if not cfg['enabled']:return {'status':'disabled','online_results_changed':False}
    if not (output/'maintenance/batch-settled.json').exists():raise ValueError('Online batch has not fully settled')
    if model_factory is None:
        from vlm.codex_vlm import CodexVisionModel
        model_factory=lambda:CodexVisionModel(role='post_task_planner',model='gpt-6.1-sol',reasoning_effort='high')
    results=[]
    with RunLock(output/'maintenance/owner'):
        for path in sorted((output/'maintenance/jobs').glob('*/job.json')):
            folder=path.parent;job=load(path);state=load(folder/'status.json')
            if job['batch_sha256']!=load(output/'maintenance/batch-settled.json')['batch_sha256']:raise ValueError('Maintenance batch identity changed')
            if state['status']=='complete' or state['attempts']>=cfg['attempts']:continue
            # Unknown external work blocks a blind retry of this maintenance job only.
            if state['status']=='execution_unknown':continue
            state.update(status='running',attempts=state['attempts']+1);save(folder/'status.json',state)
            try:
                _execute(root,folder/('attempt-'+str(state['attempts'])),job,cfg,model_factory())
                state['status']='complete'
            except Exception as exc:
                state.update(status='execution_unknown' if getattr(exc,'outcome_unknown',False) else 'failed',error_type=type(exc).__name__)
            save(folder/'status.json',state);results.append({'job_id':job['id'],**state})
        bundle=merge_candidates(output)
        if load(bundle)['contributions']:
            curate_candidate_revision(root,output,bundle,cfg,model_factory)
    return {'status':'settled','jobs':results,'candidate_bundle':str(bundle),'online_results_changed':False}


def merge_candidates(output):
    """One cross-task candidate input; no active-library writes or new evaluation."""
    output=Path(output);rows=[]
    for path in sorted((output/'maintenance/jobs').glob('*/attempt-*/contribution.json')):
        value=load(path);rows.append({'path':str(path),'sha256':sha(path),**value})
    body={'version':VERSION,'contributions':rows,'activation':'candidate_only_requires_user_review',
          'scope':'Cross-task source bundle for the delegated curation pass; shared explanations and conflicting conditions remain attributed.'}
    identity=signature(body);directory=output/'maintenance/candidates'/identity
    immutable(directory/'bundle.json',body)
    (directory/'README.md').write_text('# Candidate contributions for one reviewed library revision\n\n'+'\n\n'.join('## '+r['job_id']+'\n\n'+r['text'] for r in rows))
    return directory/'bundle.json'


def curate_candidate_revision(root,output,bundle,cfg,model_factory):
    """A separate post-batch curation pass produces proposed text, never applies it."""
    bundle=Path(bundle)
    target=bundle.parent/'revision'
    if (target/'status.json').exists():return
    jobs=[load(p) for p in (Path(output)/'maintenance/jobs').glob('*/job.json')]
    if not jobs:return
    source=next((j for j in jobs if j['experience_mode']=='full'),jobs[0])
    job=copy.deepcopy(source)
    job['id']='batch-curation-'+bundle.parent.name
    job['topic']='Cross-task curation: consolidate useful judgments, reconcile conditions and propose exact next-version entry/summary/navigation/manual text. Avoid one new entry per task; state no change when warranted. No publication.'
    job['additional_sources']={'candidate-bundle':str(bundle),'candidate-reading-page':str(bundle.parent/'README.md')}
    for i,row in enumerate(load(bundle)['contributions']):job['additional_sources']['contribution-'+str(i+1)]=row['path']
    try:
        contribution=_execute(root,target,job,cfg,model_factory())
        (bundle.parent/'candidate-revision.md').write_text(contribution['text']+'\n')
        save(target/'status.json',{'status':'complete','active_library_changed':False})
    except Exception as exc:
        save(target/'status.json',{'status':'execution_unknown' if getattr(exc,'outcome_unknown',False) else 'failed','error_type':type(exc).__name__,'active_library_changed':False})


def enqueue_planner_once(root,output,topic,settlement,batch):
    """Adapt genuine one-call work; no loop events or retrospective self-report."""
    if topic.get('split')!='test':return None
    run=Path(output)/'methods'/topic['id']/'planner-once/planner'
    if not (run/'call/returned.json').exists() or not (run/'call/response.txt').exists():return None
    state={'config':{'workflow':'single_planner_trace','execution':{'experience_mode':'none'}},
           'request':{'text':topic['request']},'status':'settled','final':settlement,
           'events':[{'event_id':'planning','source_call':str(run/'call'),'scope':'The actual single planning call; no loop trajectory is implied'}],
           'trace_adaptation':{'plan':str(run/'plan.json'),'input':str(run/'call/input.json'),
                'response':str(run/'call/response.txt'),'response_sha256':sha(run/'call/response.txt')}}
    immutable(run/'state.json',state)
    return enqueue(root,output,run,split='test',topic=topic['id'],method='planner-once',batch_sha256=batch['sha256'])
