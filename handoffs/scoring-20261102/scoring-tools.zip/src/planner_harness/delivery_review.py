"""A delivery proposal, a valid reused/new report, and a real Planner confirmation."""
from __future__ import annotations

import copy
import json
from pathlib import Path

from .common import load, save, sha
from .execution import immutable, signature
from .integrity import IntegrityError
from .json_output import decode_object

PROTOCOL = 'creative-delivery-review-v4-paged-auto'


def invalidate(state, reason, event_id):
    identity = state.get('active_delivery_proposal')
    if identity:
        proposal = state['delivery_reviews'][identity]
        proposal.update(status='superseded', invalidation={'reason':reason,'event_id':event_id})
        state['active_delivery_proposal'] = None


def binding(state, identity):
    return {'protocol':PROTOCOL, 'candidate_id':identity,
            'candidate_sha256':state['videos'][identity]['sha256'],
            'source_sha256':state['videos']['source']['sha256'],
            'request_sha256':signature({'text':state['request']['text']}),
            'critic_profile_sha256':state['config']['execution']['critic']['frozen_profile']['sha256']}


def review_payload(harness, identity, proposal_id):
    state = harness.state
    proposal = state['delivery_reviews'][proposal_id]
    if proposal['binding'] != binding(state, identity):
        raise ValueError('Delivery proposal binding changed')
    allowed = {'path','sha256','fps','frames','duration_seconds','width','height'}
    videos = {i:{k:v for k,v in state['videos'][i].items() if k in allowed} for i in ['source',identity]}
    return {'video_id':identity,'videos':videos,'original':videos['source'],
            'request':state['request']['text'],'track':state['config']['execution']['task_track'],'compare_to':None,'focus':'','extra_checks':[],
            'critic':copy.deepcopy(state['config']['execution']['critic']),
            'delivery_review':{'protocol':PROTOCOL,'proposal_id':proposal_id,
                               'binding_sha256':signature(proposal['binding'])}}


def propose(harness, args, event_id, *, origin='planner_finish'):
    from .execution import request_job
    state = harness.state
    identity = args['video']
    proposal_id = event_id + '-delivery'
    body = {'id':proposal_id,'event_id':event_id,'origin':origin,
            'binding':binding(state,identity),'finish_arguments':copy.deepcopy(args)}
    immutable(harness.output/'delivery-proposals'/proposal_id/'proposal.json',body)
    proposal = state.setdefault('delivery_reviews',{}).setdefault(proposal_id,{**body,'status':'pending','planner_inputs':{}})
    if any(proposal.get(k)!=v for k,v in body.items()):
        raise ValueError('Delivery proposal identity was reused with different inputs')
    state['active_delivery_proposal'] = proposal_id
    rejected = {}
    for job_id in reversed(state.get('evaluations', {})):
        if state['evaluations'][job_id].get('video_id') != identity:
            continue
        try:
            feedback = validated_feedback(harness.output, state, identity, job_id)
        except (ValueError, KeyError, TypeError, OSError):
            raise IntegrityError('Collected review integrity verification failed; explicit reconciliation required') from None
        proposal.update(review_job=job_id, review_origin='reused', status='ready',
                        response_sha256=sha(harness.output/'jobs'/job_id/'response.json'),
                        feedback_sha256=signature(feedback),collection_event_id=job_id+'-result')
        immutable(harness.output/'delivery-proposals'/proposal_id/'review-binding.json',
                  {k:proposal[k] for k in ('review_job','review_origin','response_sha256','feedback_sha256')})
        return {'status':'review_ready','proposal_id':proposal_id,'delivery_status':'proposed_not_confirmed',
                'message':'The matching valid report is reused. It will be supplied completely in your next model input; decide whether to confirm this candidate or continue work.'}
    prior = [key for key, job in state.get('jobs', {}).items()
             if job['kind'] == 'critique' and job['payload']['video_id'] == identity]
    if prior:
        job_id = prior[-1]
        folder = harness.output/'jobs'/job_id
        if not (folder/'response.json').exists() or not (folder/'collected.json').exists():
            raise IntegrityError('Existing review has no final collected outcome; reconcile that job')
        response = load(folder/'response.json')
        if response != load(folder/'collected.json') or response.get('request_sha256') != state['jobs'][job_id]['sha256'] or response.get('status') != 'failed' or response.get('outcome_unknown'):
            raise IntegrityError('Existing failed review receipt is inconsistent; reconcile that job')
        issue = rejected.get(job_id, 'The original review request has no valid collected report.')
        proposal.update(review_job=job_id, review_origin='existing_request', status='failed', review_issue=issue)
        from .resources import settle
        settle(state, 'No usable report after the existing bounded review attempts: ' + issue, status='execution_failed')
        save(harness.output/'final.json', state['final'])
        return {'status': 'review_failed', 'proposal_id': proposal_id, 'job_id': job_id,
                'delivery_status': 'failed_not_delivered',
                'message': 'The task is settled as an explicit review failure; original attempts remain unchanged.'}
    raise IntegrityError('Generated candidate lacks its automatic review; reconcile the original generation/review before delivery')


def before_finish(harness, args, event_id):
    state = harness.state
    identity = args.get('video')
    if state['config'].get('delivery_review_protocol') != PROTOCOL:
        raise ValueError('Creative delivery requires an explicit delivery-review protocol migration')
    if identity in {None,'source'} or state['videos'][identity].get('imported'):
        raise ValueError('Successful delivery requires a generated candidate')
    if not isinstance(args.get('message'),str) or not args['message'].strip():
        raise ValueError('Use the existing message field for a concise delivery explanation')
    active_id = state.get('active_delivery_proposal')
    proposal = state.get('delivery_reviews',{}).get(active_id)
    if proposal and proposal['binding'] != binding(state,identity):
        invalidate(state,'delivery candidate changed',event_id)
        proposal = None
    if proposal:
        if proposal['status'] in {'ready','confirmed'}:
            proof = confirmation(harness.output,state,proposal,event_id)
            proposal.update(status='confirmed',confirmation=proof)
            immutable(harness.output/'delivery-proposals'/proposal['id']/'confirmation.json',proof)
            return {'status':'confirmed','proof':proof}
        if proposal['status']=='pending':
            return {'status':'pending','job_id':proposal['review_job'],'proposal_id':proposal['id'],
                    'delivery_status':'proposed_not_confirmed'}
        raise ValueError('The delivery review is unresolved; no replacement review was submitted')
    return propose(harness,args,event_id)


def collected(harness, job, response):
    marker = job['payload'].get('delivery_review')
    if not marker:
        return
    state = harness.state
    proposal = state['delivery_reviews'][marker['proposal_id']]
    if marker['binding_sha256']!=signature(proposal['binding']) or proposal['binding']!=binding(state,job['payload']['video_id']):
        raise ValueError('Delivery report does not match its proposal')
    proposal.update(status='ready',response_sha256=sha(harness.output/'jobs'/job['id']/'response.json'),
                    feedback_sha256=signature(response['payload']),
                    collection_event_id=job['id']+'-result')
    immutable(harness.output/'delivery-proposals'/proposal['id']/'review-binding.json',
              {k:proposal[k] for k in ('review_job','review_origin','response_sha256','feedback_sha256')})


def context(state):
    identity = state.get('active_delivery_proposal')
    proposal = state.get('delivery_reviews',{}).get(identity)
    if not proposal:
        return {'protocol':PROTOCOL,'status':'no_active_proposal',
                'next_action':'A satisfied finish first proposes a candidate and reuses its automatic report. Only a later Planner finish after the full report in the new proposal context confirms delivery.'}
    result = {'protocol':PROTOCOL,'proposal_id':identity,'binding':copy.deepcopy(proposal['binding']),
              'review_job':proposal['review_job'],'status':proposal['status']}
    if proposal['status'] in {'ready','confirmed'}:
        result['report'] = copy.deepcopy(state['evaluations'][proposal['review_job']]['report'])
        result['task_metrics'] = copy.deepcopy(state['evaluations'][proposal['review_job']].get('task_metrics'))
        result['review_origin'] = proposal['review_origin']
        result['next_action'] = ('The complete delivery report is supplied here for this proposal. Decide whether to finish with this same candidate and a concise explanation, inspect evidence, change candidate, or generate again. Scores and unknowns impose no acceptance threshold.')
    return result


def record_input(harness, event_id, call_dir):
    state = harness.state
    identity = state.get('active_delivery_proposal')
    proposal = state.get('delivery_reviews',{}).get(identity)
    if not proposal or proposal['status'] not in {'ready','confirmed'}:
        return
    saved = load(call_dir/'input.json')
    visible = json.loads(saved['user_text'])
    expected = context(state)
    if event_id == proposal['event_id']:
        raise ValueError('Delivery needs a subsequent Planner input')
    complete = visible.get('delivery_review') == expected
    pages = visible_fragments(visible,state,proposal)
    if not complete and not pages:
        raise ValueError('Delivery input needs the complete bound report or an exact report page')
    receipt = {'input_path':str(call_dir/'input.json'),'input_sha256':sha(call_dir/'input.json'),
               'proposal_id':identity,'feedback_sha256':proposal['feedback_sha256'],
               'complete_report':complete,'report_pages':pages}
    old = proposal.setdefault('planner_inputs',{}).get(event_id)
    if old is not None and old != receipt:
        raise ValueError('Recorded delivery-report exposure changed')
    proposal['planner_inputs'][event_id] = receipt
    harness.checkpoint()


def validated_feedback(run, state, identity, job_id):
    """Validate the original report under its own legitimate focus/comparison/checks."""
    from critic_harness.one_shot import validate_report, verify_profile
    for i in ['source',identity]:
        if sha(state['videos'][i]['path']) != state['videos'][i]['sha256']:
            raise ValueError('Delivery media changed')
    job = state['jobs'][job_id]
    if job['kind']!='critique' or job['payload']['video_id']!=identity or job['payload']['request']!=state['request']['text']:
        raise ValueError('Cached review belongs to a different candidate or request')
    folder = run/'jobs'/job['id']
    if load(folder/'request.json') != job or signature({k:v for k,v in job.items() if k!='sha256'}) != job['sha256']:
        raise ValueError('Delivery review signed request changed')
    response = load(folder/'response.json')
    if response['status']!='complete' or response['request_sha256']!=job['sha256'] or response.get('mode')!=job['mode']:
        raise ValueError('Delivery review has no complete matching response')
    if load(folder/'collected.json')!=response:
        raise ValueError('Delivery report was not collected unchanged')
    feedback = response['payload']
    packet = load(feedback['request_path'])
    visible = json.loads(packet['user_text'])
    frozen = state['config']['execution']['critic']['frozen_profile']
    verify_profile(frozen)
    if job['payload']['critic']['frozen_profile']!=frozen or feedback.get('usage')!='online_feedback' or feedback.get('profile_sha256')!=frozen['sha256'] or feedback.get('protocol')!=frozen['protocol_id'] or feedback.get('video_id')!=identity:
        raise ValueError('Cached review protocol/model differs from this task')
    if packet['profile_sha256']!=frozen['sha256'] or packet['system_prompt']!=frozen['rubric']:
        raise ValueError('Delivery review rubric changed')
    if visible['original_request']!=state['request']['text'] or visible['candidate_id']!=identity or not {'source',identity}<=set(visible['videos']) or set(visible['videos'])!=set(job['payload']['videos']):
        raise ValueError('Delivery review task/evidence identity changed')
    if visible['focus']!=job['payload'].get('focus','') or visible['compare_to']!=job['payload'].get('compare_to') or [c['text'] for c in visible['extra_checks']]!=job['payload'].get('extra_checks',[]) or visible.get('requested_events',[])!=job['payload'].get('events',[]):
        raise ValueError('Cached review focus/comparison/checks differ from its signed request')
    for i,v in visible['videos'].items():
        if v['sha256']!=job['payload']['videos'][i]['sha256'] or v['sha256']!=state['videos'][i]['sha256']:
            raise ValueError('Delivery review media binding changed')
    for frame in packet['images']:
        if sha(frame['path'])!=frame['sha256']:
            raise ValueError('Delivery evidence changed')
    from .report_call import verify_answer
    from critic_harness.one_shot import online_projection
    call = verify_answer(folder/'one-shot-critic', feedback['report'], project=online_projection)
    sent = load(call/'input.json')
    if sent['model']!=frozen['model'] or sent['reasoning_effort']!=frozen['reasoning_effort'] or sent['system_prompt']!=packet['system_prompt'] or sent['user_text']!=packet['user_text']:
        raise ValueError('Original Critic call identity/input does not match the frozen report')
    if sent['images']!=[{'path':e['path'],'sha256':e['sha256']} for e in packet['images']]:
        raise ValueError('Original Critic call evidence differs from its packet')
    from critic_harness.event_review import verify_records
    from types import SimpleNamespace
    verify_records(folder/'one-shot-critic',packet,SimpleNamespace(model=frozen['model'],reasoning_effort=frozen['reasoning_effort']))
    if feedback.get('coverage')!=visible.get('coverage'):
        raise ValueError('Online temporal coverage differs from reviewed evidence')
    if feedback.get('evidence')!=packet['images']+packet.get('reviewed_event_images',[]):
        raise ValueError('Online event evidence differs from reviewed packet')
    from evaluation.task_metrics import verify as verify_diagnostics
    diagnostics = verify_diagnostics(folder/'one-shot-critic/task-metrics',
        SimpleNamespace(model=frozen['model'],reasoning_effort=frozen['reasoning_effort']), expected_packet=packet, usage='online_feedback')
    if feedback.get('task_metrics') != diagnostics or state['evaluations'][job['id']].get('task_metrics') != diagnostics:
        raise ValueError('Planner task diagnostics differ from the reviewed report')
    if visible['task_spec']['track'] != job['payload'].get('track','long') or feedback.get('track') != visible['task_spec']['track']:
        raise ValueError('Online task track changed')
    validate_report(feedback['report'],packet)
    if state['evaluations'][job['id']]['report']!=feedback['report']:
        raise ValueError('Planner delivery report differs from the returned report')
    return feedback


def checked_feedback(run, state, proposal):
    identity = proposal['binding']['candidate_id']
    if proposal['binding']!=binding(state,identity):
        raise ValueError('Delivery candidate/request/profile binding changed')
    body = {k:proposal[k] for k in ('id','event_id','origin','binding','finish_arguments')}
    if load(run/'delivery-proposals'/proposal['id']/'proposal.json')!=body:
        raise ValueError('Original delivery proposal changed')
    job = state['jobs'][proposal['review_job']]
    if proposal['review_origin']=='requested' and job['payload'].get('delivery_review')!={
        'protocol':PROTOCOL,'proposal_id':proposal['id'],'binding_sha256':signature(proposal['binding'])}:
        raise ValueError('Requested review does not belong to this proposal')
    feedback = validated_feedback(run,state,identity,job['id'])
    if sha(run/'jobs'/job['id']/'response.json')!=proposal['response_sha256'] or signature(feedback)!=proposal['feedback_sha256']:
        raise ValueError('Bound delivery report changed')
    if load(run/'delivery-proposals'/proposal['id']/'review-binding.json')!={k:proposal[k] for k in ('review_job','review_origin','response_sha256','feedback_sha256')}:
        raise ValueError('Delivery report reuse/request binding changed')
    return feedback


def confirmation(run, state, proposal, event_id):
    run = Path(run)
    feedback = checked_feedback(run,state,proposal)
    exposure = proposal.get('planner_inputs',{}).get(event_id)
    if not exposure or event_id==proposal['event_id']:
        raise ValueError('Delivery needs a new Planner response after its complete report for this proposal')
    path = run/'calls'/event_id/'input.json'
    if sha(path)!=exposure['input_sha256'] or exposure['feedback_sha256']!=proposal['feedback_sha256']:
        raise ValueError('Delivery confirmation model input changed')
    saved = load(path)
    visible = json.loads(saved['user_text'])
    delivered = visible.get('delivery_review',{})
    complete = delivered.get('proposal_id')==proposal['id'] and delivered.get('binding')==proposal['binding'] and delivered.get('report')==feedback['report'] and delivered.get('task_metrics')==feedback['task_metrics'] and delivered.get('status')=='ready'
    if not complete:
        seen = set()
        for identity,record in proposal.get('planner_inputs',{}).items():
            if identity > event_id:continue
            prior = run/'calls'/identity/'input.json'
            if sha(prior)!=record['input_sha256']:
                raise ValueError('Paged delivery input changed')
            actual = json.loads(load(prior)['user_text'])
            pages = visible_fragments(actual,state,proposal)
            # A prepared but never answered input does not establish exposure.
            response_path = prior.parent/'response.txt'
            transport_input = prior.parent/'transport/input.json'
            if not response_path.exists() or not transport_input.exists():continue
            returned=prior.parent/'transport/returned.json'
            transport_answer=prior.parent/'transport/response.txt'
            if not returned.exists() or not transport_answer.exists() or load(returned)['sha256']!=sha(response_path) or transport_answer.read_text()!=response_path.read_text():
                raise ValueError('Paged delivery exposure has no matching returned answer')
            if load(transport_input)['user_text'] != load(prior)['user_text']:
                raise ValueError('Paged delivery transport differs from prepared input')
            seen.update(pages)
        total = report_fragment(state,proposal,0)['total_pages']
        if seen != set(range(total)):
            raise ValueError('Read every page of the bound delivery report before confirming')
    call = path.parent
    response = call/'response.txt'
    transport = call/'transport'
    if (transport/'response.txt').read_text()!=response.read_text() or load(transport/'returned.json')['sha256']!=sha(response):
        raise ValueError('Delivery confirmation is not the returned Planner response')
    sent = load(transport/'input.json')
    if sent['user_text']!=saved['user_text'] or sent['system_prompt']!=saved['system_prompt']:
        raise ValueError('Saved Planner input differs from the actual transport input')
    if sent['model']!=state['config']['model'] or sent['reasoning_effort']!=state['config']['reasoning_effort']:
        raise ValueError('Delivery confirmation used a different Planner identity')
    from .json_output import decode_object
    decision = decode_object(response.read_text())
    args = decision.get('arguments',{})
    if decision.get('action')!='finish' or args.get('video')!=proposal['binding']['candidate_id'] or args.get('stop_reason','satisfied')!='satisfied' or not isinstance(args.get('message'),str) or not args['message'].strip():
        raise ValueError('Post-report Planner response did not confirm this delivery')
    return {'protocol':PROTOCOL,'proposal_id':proposal['id'],'proposal_event_id':proposal['event_id'],
            'review_job':proposal['review_job'],'review_response_sha256':proposal['response_sha256'],
            'review_origin':proposal['review_origin'],
            'feedback_sha256':proposal['feedback_sha256'],'planner_event_id':event_id,
            'planner_input_sha256':sha(path),'planner_response_sha256':sha(response),
            'candidate_sha256':proposal['binding']['candidate_sha256'],'message':args['message']}


def verify(run, state):
    run = Path(run)
    if state['config'].get('delivery_review_protocol')!=PROTOCOL:
        raise ValueError('Old creative completion needs an explicit delivery-review migration')
    proof = state.get('final',{}).get('delivery_review')
    if not proof:
        raise ValueError('Delivery lacks proposal/review/Planner-confirmation evidence')
    proposal = state.get('delivery_reviews',{}).get(proof.get('proposal_id'))
    if not proposal or proposal['status']!='confirmed' or state.get('active_delivery_proposal')!=proposal['id']:
        raise ValueError('Delivery proposal is stale or unconfirmed')
    expected = confirmation(run,state,proposal,proof['planner_event_id'])
    if proof!=expected or proposal.get('confirmation')!=expected or load(run/'delivery-proposals'/proposal['id']/'confirmation.json')!=expected:
        raise ValueError('Delivery confirmation relationship changed')
    events = {e['event_id']:e for e in state['events']}
    event = events.get(proof['planner_event_id'],{})
    if event.get('status')!='ok' or event.get('request')!=decode_object((run/'calls'/proof['planner_event_id']/'response.txt').read_text()):
        raise ValueError('Delivery confirmation is not an accepted subsequent Planner event')
    order = [e['event_id'] for e in state['events']]
    if proposal['collection_event_id'] not in order or order.index(proposal['collection_event_id'])>=order.index(proof['planner_event_id']):
        raise ValueError('Delivery report was not returned before confirmation')
    if state['final']['video']!=proposal['binding']['candidate_id'] or state['final']['message']!=proof['message']:
        raise ValueError('Final delivery differs from the confirmed Planner decision')
    return proof


def report_fragment(state, proposal, number):
    value = state['evaluations'][proposal['review_job']]
    text = json.dumps({'report':value['report'],'task_metrics':value['task_metrics']},ensure_ascii=False,indent=2)
    size = 2048
    total = max(1,(len(text)+size-1)//size)
    if type(number) is not int or not 0 <= number < total:raise ValueError('Unknown delivery report page')
    return {'proposal_id':proposal['id'],'feedback_sha256':proposal['feedback_sha256'],
            'page':number,'total_pages':total,'start_char':number*size,'end_char':min(len(text),(number+1)*size),
            'text':text[number*size:(number+1)*size],
            'next':{'action':'history','arguments':{'delivery_report_page':number+1}} if number+1<total else None}


def visible_fragments(value,state,proposal):
    pages = set()
    def visit(node):
        if isinstance(node,dict):
            fragment = node.get('delivery_report_fragment')
            if isinstance(fragment,dict) and fragment.get('proposal_id')==proposal['id']:
                number = fragment.get('page')
                if fragment != report_fragment(state,proposal,number):raise ValueError('Delivery report fragment changed')
                pages.add(number)
            for item in node.values():visit(item)
        elif isinstance(node,list):
            for item in node:visit(item)
    visit(value)
    return sorted(pages)
