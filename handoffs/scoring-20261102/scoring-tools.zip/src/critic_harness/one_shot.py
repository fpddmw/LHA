"""Frozen online review with bounded, question-led continuous-event evidence."""
from __future__ import annotations

import copy
import json
import re
from pathlib import Path

from planner_harness.common import load, save, sha
from planner_harness.execution import signature, immutable
from planner_harness.video import Video

PROTOCOL = "lha-creative-review-v6-integrated-task-diagnostics"
DIMENSIONS = ("instruction_adherence", "content_preservation", "temporal_consistency",
              "visual_integrity", "aesthetic_coherence")
from .event_review import POLICY, REPORT_GUIDE



def frozen_profile():
    definitions = Path(__file__).with_name("SCORE_DEFINITIONS.md")
    rubric = Path(__file__).with_name("CREATIVE_RUBRIC.md").read_text(encoding="utf-8")
    # The common rubric is also used by independent final review. Only this
    # online rendering adds integrated diagnostics and echoed questions.
    rubric = rubric.replace("unassessed. main_scores", "unassessed, task_diagnostics. main_scores").replace(
        "For every supplemental check, return id, status", "For every supplemental check, return id, question (the exact original question text), status")
    from evaluation.task_metrics import PROMPT as DIAGNOSTICS_GUIDE
    body = {"protocol_id": PROTOCOL, "rubric": rubric.replace("{{SCORE_DEFINITIONS}}", definitions.read_text(encoding="utf-8")) + REPORT_GUIDE + "\nIn this same main report, place the following diagnostics object under task_diagnostics. Do not start another review.\n" + DIAGNOSTICS_GUIDE.replace("Return exactly items, required_correspondence, unrequested_damage, specialties, aesthetics.", "task_diagnostics contains exactly items, required_correspondence, unrequested_damage, specialties, aesthetics. These are nested fields of task_diagnostics."),
            "score_definitions_sha256": sha(definitions),
            "dimensions": list(DIMENSIONS), "evidence_policy": POLICY,
            "model": "gpt-6.1-sol", "reasoning_effort": "high", "schema_version": 6,
            "implementation_sha256": {"review": sha(__file__),
                "event_review": sha(Path(__file__).with_name("event_review.py")),
                **{name:sha(Path(__file__).parents[1] / "evaluation" / (name + ".py")) for name in ("task_spec","task_metrics","registry")},
                "continuous_observation": sha(Path(__file__).parents[1] / "planner_harness/event_observation.py"),
                "model_adapter": sha(Path(__file__).parents[1] / "vlm/codex_vlm.py"),
                "video": sha(Path(__file__).parents[1] / "planner_harness/video.py"),
                "transport": sha(Path(__file__).parents[1] / "planner_harness/model_call.py"),
                "json_output": sha(Path(__file__).parents[1] / "planner_harness/json_output.py"),
                "report_recovery": sha(Path(__file__).parents[1] / "planner_harness/report_call.py"),
                "native_evidence": sha(Path(__file__).with_name("evidence.py"))}}
    return {**body, "sha256": signature(body)}


def verify_profile(profile):
    if profile.get("sha256") != signature({k: v for k, v in profile.items() if k != "sha256"}):
        raise ValueError("Frozen review profile hash mismatch")
    if profile != frozen_profile():
        raise ValueError("This runtime differs from the frozen review profile; use the recorded code snapshot")


def prepare_request(request, candidate_id, videos, directory, profile, *, compare_to=None, focus="", extra_checks=None, events=None, track="long"):
    """Only whitelisted fields reach the model. Prompts/ancestry/preferences stay out."""
    verify_profile(profile)
    if not isinstance(focus, str) or not isinstance(extra_checks or [], list) or any(
            not isinstance(c, str) or not c.strip() for c in (extra_checks or [])):
        raise ValueError("focus is text; extra_checks is a list of nonempty text")
    validate_focus(focus, extra_checks or [])
    from .event_review import validate_events
    validate_events(events or [])
    ids = list(dict.fromkeys(["source", candidate_id] + ([compare_to] if compare_to else [])))
    if candidate_id == "source" or any(i not in videos for i in ids):
        raise ValueError("Review a candidate with the original source and an available comparison")
    images, evidence, video_meta = [], [], {}
    directory = Path(directory)
    for identity in ids:
        info = videos[identity]
        if sha(info["path"]) != info["sha256"]:
            raise ValueError("Review video changed")
        video = Video(info["path"], directory / identity)
        video_meta[identity] = {k: video.info[k] for k in ("sha256", "fps", "frames", "duration_seconds", "width", "height")}
        groups = [("overview", video.observe("overview", count=POLICY["overview_frames"]))]
        for group, observation in groups:
            for frame in observation["frames"]:
                evidence_id = f"{identity}:{observation['observation_id']}:{frame['frame_index']}"
                images.append(frame["path"])
                evidence.append({"id": evidence_id, "video_id": identity, "kind": group,
                                 "attachment": len(images), **frame})
    from evaluation.task_spec import build
    task = build(request, video_meta["source"]["duration_seconds"], track=track)
    checks = [{"id": f"check-{i + 1}", "text": c} for i, c in enumerate(extra_checks or [])]
    visible = {"protocol_id": profile["protocol_id"], "candidate_id": candidate_id,
               "original_request": request, "task_spec": task, "videos": video_meta, "compare_to": compare_to,
               "focus": focus, "extra_checks": checks, "requested_events": events or [], "evidence_policy": profile["evidence_policy"],
               "evidence": [{k: v for k, v in e.items() if k != "path"} for e in evidence]}
    packet = {"system_prompt": profile["rubric"], "user_text": json.dumps(visible, ensure_ascii=False, indent=2),
              "images": evidence, "profile_sha256": profile["sha256"]}
    immutable(directory / "request.json", packet)
    return packet, images


def _keys(value, required):
    if not isinstance(value, dict) or set(value) != set(required):
        raise ValueError("Unexpected review fields; use the frozen descriptive schema")


def validate_focus(focus, checks):
    """Reject evident steering without rewriting questions or calling a model."""
    text = " ".join([focus, *checks])
    steering = (r"\b(?:I|we|Planner)\s+(?:prefer|expect|want|favor)s?\b|"
                r"\b(?:scores?|grades?)\s+(?:should|must|need to)\s+be\b|"
                r"\b(?:give|assign|award|set|rate|mark)\b.{0,35}\b(?:scores?|grades?|rating)\b.{0,15}\b[0-4]\b|"
                r"\b(?:rate|mark|score)\s+(?:it|this|the candidate|the video)\s+(?:as\s+)?[0-4]\b|"
                r"\b(?:give|assign|award)\s+(?:it|this|the candidate)\s+(?:a\s+)?[0-4]\b|"
                r"\b(?:ignore|override|replace|change)\b.{0,35}\b(?:rubric|scale|criteria|scores?|instructions)\b|"
                r"\b(?:best|preferred|winning)\s+(?:candidate|version)|"
                r"\b(?:whether|should|shall)\s+(?:we|I|the planner)\s+(?:stop|continue|generate|edit)|"
                r"\b(?:because|so that)\b.{0,60}\b(?:generate|regenerate|continue editing)\b")
    if re.search(steering, text, re.I):
        raise ValueError("Critic focus/checks must ask neutral observable questions, without desired scores, preferences or next-action reasoning")


def validate_report(report, packet):
    visible = json.loads(packet["user_text"])
    fields = ("protocol_id", "candidate_id", "main_scores", "comparisons", "extra_checks", "unassessed")
    online = visible["protocol_id"] == PROTOCOL
    _keys(report, (*fields,"task_diagnostics") if online else fields)
    if online:
        from evaluation.task_metrics import validate as validate_diagnostics
        validate_diagnostics(report["task_diagnostics"],packet)
    if visible["protocol_id"] not in {PROTOCOL, "lha-low-high-final-v3"} or report["protocol_id"] != visible["protocol_id"] or report["candidate_id"] != visible["candidate_id"]:
        raise ValueError("Review identity mismatch")
    _keys(report["main_scores"], DIMENSIONS)
    refs = {e["id"]: e for e in visible["evidence"]}

    def evidence(row, required=False):
        if not isinstance(row.get("reason"), str) or not row["reason"].strip():
            raise ValueError("Review needs an observable reason")
        ids = row.get("evidence_refs")
        if not isinstance(ids, list) or any(not isinstance(i, str) or i not in refs for i in ids):
            raise ValueError("Unknown evidence reference")
        if required and not ids:
            raise ValueError("An assessed finding needs visual evidence")
        for key in ("limitations",):
            if key in row and (not isinstance(row[key], list) or any(not isinstance(v, str) for v in row[key])):
                raise ValueError("Limitations must be text entries")
        return [refs[i] for i in ids]

    for dimension, row in report["main_scores"].items():
        _keys(row, ("status", "score", "reason", "evidence_refs", "limitations"))
        if row["status"] == "scored":
            if type(row["score"]) is not int or not 0 <= row["score"] <= 4:
                raise ValueError("Scores are integers from 0 through 4")
        elif row["status"] not in {"unknown", "not_assessed", "not_applicable"} or row["score"] is not None:
            raise ValueError("Unassessed scores must remain null with an explicit status")
        cited = evidence(row, row["status"] == "scored")
        if row["status"] == "scored":
            if visible["candidate_id"] not in {e["video_id"] for e in cited}:
                raise ValueError("A score must cite the candidate")
            if dimension == "content_preservation" and "source" not in {e["video_id"] for e in cited}:
                raise ValueError("Preservation needs source and candidate evidence")
            if dimension == "temporal_consistency":
                dense = [e for e in cited if e["kind"] == "consecutive_frames" and e["video_id"] == visible["candidate_id"]]
                # Window endpoints identify continuous evidence only when every
                # intervening frame was supplied in that same dense window.
                supported = False
                for first in dense:
                    window = first["id"].rsplit(":", 1)[0]
                    available = {e["frame_index"] for e in refs.values() if e["kind"] == "consecutive_frames"
                                 and e["video_id"] == visible["candidate_id"] and e["id"].rsplit(":", 1)[0] == window}
                    for last in dense:
                        if last["id"].rsplit(":", 1)[0] == window and last["frame_index"] > first["frame_index"]:
                            supported |= set(range(first["frame_index"], last["frame_index"] + 1)) <= available
                if not supported:
                    raise ValueError("Temporal scores need consecutive candidate evidence")
    if not isinstance(report["comparisons"], list) or not isinstance(report["extra_checks"], list):
        raise ValueError("Comparisons and supplemental checks must be lists")
    for row in report["comparisons"]:
        _keys(row, ("against", "dimension", "change", "reason", "evidence_refs"))
        if not visible["compare_to"] or row["against"] != visible["compare_to"] or row["dimension"] not in DIMENSIONS:
            raise ValueError("Comparison is outside the requested evidence")
        if row["change"] not in {"better", "same", "worse", "unknown"}:
            raise ValueError("Invalid descriptive comparison")
        cited = evidence(row, row["change"] != "unknown")
        if row["change"] != "unknown" and not {visible["candidate_id"], row["against"]} <= {e["video_id"] for e in cited}:
            raise ValueError("Comparison needs evidence from both videos")
    if visible["compare_to"] and not report["comparisons"]:
        raise ValueError("A requested comparison needs descriptive findings or an explicit unknown comparison")
    expected = [c["id"] for c in visible["extra_checks"]]
    if any(not isinstance(c, dict) for c in report["extra_checks"]):
        raise ValueError("Each supplemental check must be an object")
    if [c.get("id") for c in report["extra_checks"]] != expected:
        raise ValueError("Supplemental checks must match the request")
    for row in report["extra_checks"]:
        _keys(row, ("id", "question", "status", "reason", "evidence_refs", "limitations") if online else ("id", "status", "reason", "evidence_refs", "limitations"))
        question = next(c["text"] for c in visible["extra_checks"] if c["id"] == row["id"])
        if online and row["question"] != question:
            raise ValueError("Supplemental feedback must echo the exact original question")
        if row["status"] not in {"pass", "partial", "fail", "unknown"}:
            raise ValueError("Invalid supplemental check status")
        cited = evidence(row, row["status"] != "unknown")
        if row["status"] != "unknown":
            identities = {e["video_id"] for e in cited}
            if visible["candidate_id"] not in identities:
                raise ValueError("A supplemental candidate finding must cite the candidate")
            question = next(c["text"] for c in visible["extra_checks"] if c["id"] == row["id"])
            if re.search(r"\b(source|original|preserv\w*|retain\w*|unchanged|same as)\b", question, re.I) and "source" not in identities:
                raise ValueError("A supplemental source-relative finding must cite the source")
            if visible["compare_to"] and re.search(r"\b(compare\w*|better|worse|improv\w*)\b", question, re.I) and visible["compare_to"] not in identities:
                raise ValueError("A relative supplemental finding must cite the comparison")
    if not isinstance(report["unassessed"], list) or any(not isinstance(s, str) for s in report["unassessed"]):
        raise ValueError("unassessed must contain text limitations")
    return report


def online_projection(report):
    """Withhold explicit action instructions from online prose; preserve raw assessment.

    This narrow syntactic filter is telemetry/feedback policy, never score validity.
    Ambiguous semantics remain a documented limitation of descriptive prompting.
    """
    report = copy.deepcopy(report)
    pattern = (r"\b(recommend(?:ed|ation|ations)?|next (?:step|attempt|generation)|"
                 r"(?:you|we|the planner)\s+should\s+(?:use|generate|edit|render|select|try)|"
                 r"(?:rewrite|revise|change) the prompt|(?:choose|select|deliver) (?:v\d+|candidate)|"
                 r"(?:restart|regenerate|stop generating|continue editing)|"
                 r"(?:use|take|keep|retain)\s+(?:v\d+|source|the source|this candidate|the candidate)\s+(?:as|for)|"
                 r"(?:further|another|new)\s+(?:render|generation|pass)\b.{0,100}\b(?:would|could|will|can)|"
                 r"(?:edit|generate|render)\s+(?:again|from)|"
                 r"(?:deliver|select|choose)\s+(?:this|that|it)|"
                 r"(?:rewrite|revise|modify|strengthen|shorten)\s+(?:the|your)\s+prompt|"
                 r"using\s+v\d+\s+as\s+(?:the\s+)?base\s+would|"
                 r"rendering\s+(?:once\s+more|again)\s+from)\b")
    def safe(text):
        return "Explicit action guidance withheld by online feedback policy." if re.search(pattern, text, re.I) else text
    for row in list(report["main_scores"].values()) + report["comparisons"] + report["extra_checks"]:
        row["reason"] = safe(row["reason"])
        if "limitations" in row:
            row["limitations"] = [safe(v) for v in row["limitations"]]
    report["unassessed"] = [safe(v) for v in report["unassessed"]]
    def project_diagnostics(value):
        if isinstance(value,dict):
            for key,item in value.items():
                if key == "reason" and isinstance(item,str):value[key] = safe(item)
                else:project_diagnostics(item)
        elif isinstance(value,list):
            for item in value:project_diagnostics(item)
    project_diagnostics(report.get("task_diagnostics",{}))
    return report


def projection_fields(original, projected, path=""):
    if isinstance(original, dict):
        return [p for k in original for p in projection_fields(original[k], projected[k], path + "/" + k)]
    if isinstance(original, list):
        return [p for i, value in enumerate(original) for p in projection_fields(value, projected[i], path + "/" + str(i))]
    return [path] if original != projected else []


def run_review(payload, directory, model=None):
    from planner_harness.model_call import call_text
    directory = Path(directory) / "one-shot-critic"
    profile = payload["critic"]["frozen_profile"]
    if model is None:
        from vlm.codex_vlm import CodexVisionModel
        model = CodexVisionModel(role="online_critic", model=profile["model"], reasoning_effort=profile["reasoning_effort"])
    if model.model != profile["model"] or model.reasoning_effort != profile["reasoning_effort"]:
        raise ValueError("Critic model differs from frozen profile")
    from .event_review import prepare_online
    packet, images = prepare_online(payload["request"], payload["video_id"], payload["videos"],
        directory, profile, model, compare_to=payload.get("compare_to"), focus=payload.get("focus", ""),
        extra_checks=payload.get("extra_checks", []), events=payload.get("events", []), track=payload.get("track", "long"))
    try:
        from planner_harness.report_call import call_report
        original, answer = call_report(directory, model, packet, images, validate_report)
        report = online_projection(original)
    except (ValueError, TypeError, KeyError) as exc:
        save(directory / "invalid-report.json", {"error": str(exc), "recovery_policy": "report-recovery-v1"})
        raise
    from evaluation.task_metrics import embedded_online
    diagnostics = embedded_online(packet, directory / "task-metrics", report, answer)
    result = {"protocol": PROTOCOL, "usage": "online_feedback", "video_id": payload["video_id"],
              "profile_sha256": profile["sha256"], "report": report, "task_metrics": diagnostics,
              "track": payload.get("track", "long"),
              "review_questions":{"focus":{"id":"focus","question":payload.get("focus","")},
                  "extra_checks":[{"id":f"check-{i+1}","question":q} for i,q in enumerate(payload.get("extra_checks",[]))],
                  "events":[{"id":f"event-{i+1}","question":e["question"],"start":e["start"],"end":e["end"]} for i,e in enumerate(payload.get("events",[]))],
                  "compare_to":payload.get("compare_to")},
              "projection_fields": projection_fields(original, report), "answer_binding": answer,
              "online_policy": "explicit-action-projection-v1",
              "coverage": json.loads(packet["user_text"])["coverage"],
              "evidence": packet["images"] + packet["reviewed_event_images"], "request_path": str(directory / "request.json")}
    immutable(directory / "feedback.json", result)
    return result
