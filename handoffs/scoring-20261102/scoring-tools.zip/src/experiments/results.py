"""One video registry, with evaluation identities independent of render provenance.

Imports never consume old scores. A source/request match is checked against the
current inventory before a video is given its current sample/form/method/seed key.
"""
from __future__ import annotations

import html
import json
from pathlib import Path
import re
import uuid
from urllib.parse import quote

from planner_harness.common import load, save, sha
from planner_harness.execution import immutable, signature
from planner_harness.lock import RunLock

VERSION = "lha-video-results-v1"
SAFE = re.compile(r"[A-Za-z0-9_-]+\Z")
METHODS = ("direct", "direct-best-of-n", "planner-once", "pe", "full", "none",
           "lineage-chain", "lineage-source-restart")


def comparison_pairs():
    from .creative_benchmark import PAIRS
    return [list(pair) for pair in PAIRS + (("direct", "planner-once"), ("direct", "pe"),
        ("direct", "direct-best-of-n"), ("lineage-source-restart", "lineage-chain"))]


def inventory(repository):
    root = Path(repository).resolve()
    result = {}
    for row in load(root / "benchmark_data/benchmark.json"):
        sample = row["sample_id"]
        if not SAFE.fullmatch(sample):
            raise ValueError("Unsafe benchmark sample ID")
        for form in ("short", "long"):
            text = row.get("prompt_" + form, row.get("instruction") if form == "long" else None)
            if not isinstance(text, str) or not text.strip():
                continue
            result[sample, form] = {"sample_id": sample, "prompt_form": form,
                "source_sha256": row["source_video_sha256"], "request": text,
                "request_sha256": signature({"text": text}), "source": row["source_video"],
                "split": row["split"], "source_group": row.get("source_group", sample)}
    return result


def entry_path(root, sample, form, method, seed):
    if not isinstance(sample, str) or not SAFE.fullmatch(sample) or form not in {"short", "long"}:
        raise ValueError("A current sample and short/long prompt form are required")
    if method not in METHODS or type(seed) is not int or seed < 0:
        raise ValueError("Unknown method or invalid seed")
    return Path(root) / "entries" / sample / form / method / ("seed-" + str(seed) + ".json")


def _copy(source, target, expected):
    from .creative_benchmark import copy_verified
    return copy_verified(source, target, expected)


def import_video(repository, root, row):
    """Import one verified local output. Repeated identical imports are idempotent."""
    root = Path(root).resolve()
    index = inventory(repository)
    row = dict(row)
    request_hash = row.get("request_sha256")
    if "request" in row:
        actual = signature({"text": row["request"]})
        if request_hash and request_hash != actual:
            raise ValueError("Import request text/hash differ")
        request_hash = actual
    matches = [r for r in index.values() if r["source_sha256"] == row.get("source_sha256")
               and r["request_sha256"] == request_hash
               and (not row.get("prompt_form") or r["prompt_form"] == row["prompt_form"])]
    if row.get("sample_id"):
        matches = [r for r in matches if r["sample_id"] == row["sample_id"]]
    if len(matches) != 1:
        raise ValueError("Import must match exactly one current source, prompt and sample")
    task = matches[0]
    method, seed = row.get("method"), row.get("seed")
    path = entry_path(root, task["sample_id"], task["prompt_form"], method, seed)
    source = Path(row["video"]).resolve()
    digest = sha(source)
    if row.get("video_sha256") and row["video_sha256"] != digest:
        raise ValueError("Imported video hash differs")
    if not isinstance(row.get("generation"), dict) or not row["generation"]:
        raise ValueError("Retain the actual generation conditions with each video")
    if not isinstance(row.get("evidence"), dict) or not row["evidence"]:
        raise ValueError("Retain the original render evidence with each video")
    evidence = row["evidence"]
    if evidence.get("receipt_sha256"):
        receipt = Path(evidence["receipt"])
        if not receipt.is_file() or sha(receipt) != evidence["receipt_sha256"]:
            raise ValueError("Original render receipt is unavailable or changed")
    # Scores and stale judging artifacts deliberately have no import field.
    body = {"schema": VERSION, **task, "method": method, "seed": seed,
            "video": "media/" + digest + ".mp4", "video_sha256": digest,
            "generation": row["generation"], "evidence": evidence,
            "evaluation_status": "pending"}
    candidates = []
    for candidate in row.get("candidates", []):
        if not isinstance(candidate.get("id"), str) or not SAFE.fullmatch(candidate["id"]) or type(candidate.get("seed")) is not int or set(candidate.get("roles", [])) - {"first", "selected"}:
            raise ValueError("Invalid generated candidate identity/seed/roles")
        native = Path(candidate["video"]).resolve()
        native_sha = sha(native)
        if native_sha != candidate["video_sha256"]:
            raise ValueError("Candidate video changed")
        candidates.append({"id": candidate["id"], "seed": candidate["seed"], "roles": candidate["roles"],
            "video": "media/" + native_sha + ".mp4", "video_sha256": native_sha, "_source": native})
    if candidates:
        if len({c["id"] for c in candidates}) != len(candidates) or sum("first" in c["roles"] for c in candidates) != 1 or sum("selected" in c["roles"] for c in candidates) != 1:
            raise ValueError("Candidate set needs unique IDs and one first/selected identity")
        if next(c["video_sha256"] for c in candidates if "selected" in c["roles"]) != digest:
            raise ValueError("Selected candidate differs from the primary result")
        body["candidates"] = [{k: v for k, v in c.items() if k != "_source"} for c in candidates]
    with RunLock(root / "registry-owner"):
        if path.exists():
            old = verify_entry(root, path)
            identity = ("source_sha256", "request_sha256", "video_sha256", "generation")
            if any(old[k] != body[k] for k in identity):
                raise ValueError("This result key already names different video/conditions; inspect the conflict")
            return old
        _copy(source, root / body["video"], digest)
        for candidate in candidates:
            _copy(candidate["_source"], root / candidate["video"], candidate["video_sha256"])
        immutable(path, {**body, "sha256": signature(body)})
    return load(path)


def verify_entry(root, path):
    row = load(path)
    if row.get("schema") != VERSION or row.get("sha256") != signature({k: v for k, v in row.items() if k != "sha256"}):
        raise ValueError("Result entry identity changed")
    expected = entry_path(root, row["sample_id"], row["prompt_form"], row["method"], row["seed"])
    if expected.resolve() != Path(path).resolve():
        raise ValueError("Result stored under the wrong key")
    video = (Path(root) / row["video"]).resolve()
    if not video.is_relative_to(Path(root).resolve()) or sha(video) != row["video_sha256"]:
        raise ValueError("Result video is missing or changed")
    for candidate in row.get("candidates", []):
        candidate_path = (Path(root) / candidate["video"]).resolve()
        if not candidate_path.is_relative_to(Path(root).resolve()) or sha(candidate_path) != candidate["video_sha256"]:
            raise ValueError("Trajectory candidate is missing or changed")
    return row


def find(root, sample, form, method, seed):
    path = entry_path(root, sample, form, method, seed)
    return verify_entry(root, path) if path.exists() else None


def import_manifest(repository, root, manifest):
    path = Path(manifest)
    if path.suffix == ".jsonl":
        rows = [json.loads(line) for line in path.read_text(encoding="utf-8-sig").splitlines() if line.strip()]
    else:
        rows = load(path)
        if isinstance(rows, dict):
            rows = rows["results"]
    if not isinstance(rows, list):
        raise ValueError("Use an array, {results: [...]} or JSONL")
    return [import_video(repository, root, row) for row in rows]


def import_bernini(repository, root, run):
    """Read completed direct/official-PE cases from an existing frozen runner."""
    import sys
    scripts = str(Path(repository) / "scripts")
    if scripts not in sys.path:
        sys.path.insert(0, scripts)
    from run_bernini_benchmark import read, verify_completed
    run = Path(run).resolve()
    plan = read(run / "plan.json")
    if signature({k: v for k, v in plan.items() if k != "sha256"}) != plan["sha256"]:
        raise ValueError("Bernini plan identity changed")
    result = []
    for case in plan["cases"]:
        directory = run / "cases" / case["case_id"]
        receipt = directory / "result.json"
        if not receipt.exists() or read(receipt).get("status") != "complete":
            continue
        complete = read(receipt)
        verify_completed(directory, complete)
        binding = read(directory / "input.json")
        if binding["case"] != case or binding["plan_sha256"] != plan["sha256"]:
            raise ValueError("Bernini case does not match its frozen plan")
        result.append(import_video(repository, root, {
            "prompt_form": case["tier"], "method": case["condition"], "seed": case["seed"],
            "source_sha256": case["source_sha256"], "request": case["prompt"],
            "video": str(directory / "native.mp4"), "video_sha256": complete["output_sha256"],
            "generation": plan["generation"], "evidence": {"receipt": str(receipt),
                "receipt_sha256": sha(receipt), "input_sha256": complete["input_sha256"],
                "runtime_sha256": binding["runtime_sha256"], "original_sample_id": case["sample_id"]}}))
    return result


def _evaluation_positions(repository, root):
    positions = []
    tasks = inventory(repository)
    for path in sorted((Path(root) / "entries").glob("*/*/*/seed-*.json")):
        entry = verify_entry(root, path)
        current = tasks.get((entry["sample_id"], entry["prompt_form"]))
        if not current or any(entry[k] != current[k] for k in ("source_sha256", "request_sha256")):
            raise ValueError("Evaluation input no longer matches the current benchmark")
        base = {k: entry[k] for k in ("sample_id", "prompt_form", "method", "seed", "source_sha256", "request_sha256", "video", "video_sha256")}
        positions.append({**base, "position": "final"})
        if entry["method"] in {"full", "none"}:
            first = next((c for c in entry.get("candidates", []) if "first" in c["roles"]), None)
            if first:
                positions.append({**base, "position": "first", "video": first["video"], "video_sha256": first["video_sha256"]})
    return positions


def prepare_evaluation(repository, root, *, evaluation_id=None):
    """Start a fresh scoring namespace. No historical score/cache is imported."""
    from evaluation.low_high import profile
    from evaluation.creative import JUDGES, judge_identity
    root = Path(root).resolve()
    evaluation_id = evaluation_id or uuid.uuid4().hex
    if not SAFE.fullmatch(evaluation_id):
        raise ValueError("Evaluation ID must be one safe path component")
    directory = root / "evaluations" / evaluation_id
    if directory.exists():
        raise ValueError("A fresh evaluation requires a new ID; use score-evaluation to resume the current one")
    positions = _evaluation_positions(repository, root)
    body = {"schema": "lha-result-evaluation-v1", "evaluation_id": evaluation_id,
        "protocol_sha256": profile()["sha256"], "judges": [judge_identity(j) for j in JUDGES],
        "positions": positions, "source_task": "original request and source video under the shared scoring handbook",
        "adapter_sha256": sha(Path(__file__).parents[1] / "evaluation/creative.py"),
        "comparison_pairs": comparison_pairs(),
        "cache_scope": "this fresh evaluation only; bound additions retain the same rules"}
    with RunLock(root / "registry-owner"):
        immutable(directory / "evaluation.json", {**body, "sha256": signature(body)})
        save(root / "current-evaluation.json", {"path": str((directory / "evaluation.json").relative_to(root)),
            "sha256": sha(directory / "evaluation.json")})
    return load(directory / "evaluation.json")


def current_evaluation(root):
    from evaluation.low_high import profile
    from evaluation.creative import JUDGES, judge_identity
    root = Path(root).resolve()
    marker = root / "current-evaluation.json"
    if not marker.exists():
        return None
    pointer = load(marker)
    path = (root / pointer["path"]).resolve()
    if not path.is_relative_to(root / "evaluations") or sha(path) != pointer["sha256"]:
        raise ValueError("Current evaluation pointer changed")
    plan = load(path)
    if plan.get("schema") != "lha-result-evaluation-v1" or plan.get("sha256") != signature({k: v for k, v in plan.items() if k != "sha256"}):
        raise ValueError("Current evaluation identity changed")
    # A scoring-code change makes the old session inactive. Raw records remain.
    if plan["protocol_sha256"] != profile()["sha256"] or plan["judges"] != [judge_identity(j) for j in JUDGES] or plan.get("adapter_sha256") != sha(Path(__file__).parents[1] / "evaluation/creative.py") or plan.get("comparison_pairs") != comparison_pairs():
        return None
    positions = list(plan["positions"])
    for addition in sorted((path.parent / "additions").glob("*.json")):
        body = load(addition)
        if body.get("session_sha256") != plan["sha256"] or body.get("sha256") != signature({k: v for k, v in body.items() if k != "sha256"}):
            raise ValueError("Evaluation addition identity changed")
        positions.extend(body["positions"])
    keys = [(p["sample_id"], p["prompt_form"], p["method"], p["seed"], p.get("position", "final")) for p in positions]
    if len(keys) != len(set(keys)):
        raise ValueError("Evaluation additions contain repeated positions")
    plan = {**plan, "positions": positions}
    return path.parent, plan


def append_evaluation(repository, root):
    """Append newly collected videos under the unchanged evaluation rules."""
    root = Path(root).resolve()
    with RunLock(root / "registry-owner"):
        active = current_evaluation(root)
        if active is None:
            raise ValueError("There is no active evaluation with the current protocol")
        directory, plan = active
        key = lambda p: (p["sample_id"], p["prompt_form"], p["method"], p["seed"], p.get("position", "final"))
        previous = {key(p): p for p in plan["positions"]}
        new = []
        for position in _evaluation_positions(repository, root):
            if key(position) in previous:
                if previous[key(position)] != position:
                    raise ValueError("An existing evaluation position changed")
            else:
                new.append(position)
        if new:
            body = {"session_sha256": plan["sha256"], "positions": new}
            immutable(directory / "additions" / (signature(body) + ".json"), {**body, "sha256": signature(body)})
        return {"added": len(new), "positions": len(previous) + len(new), "evaluation_id": plan["evaluation_id"]}


def _score_key(position, judge):
    return signature({"source": position["source_sha256"], "request": position["request_sha256"],
                      "track": position["prompt_form"], "candidate": position["video_sha256"], "judge": judge})


def score_evaluation(repository, root, budget, *, models=None):
    """Explicit live entry using the current evaluator, confined to the fresh session."""
    from evaluation.creative import JUDGES, judge_identity, make_judge, judge_candidate
    from evaluation.low_high import freeze_plan
    from planner_harness.video import Video
    from planner_harness import accounting
    from planner_harness.report_call import ReportUnavailable
    repository, root = Path(repository).resolve(), Path(root).resolve()
    append_evaluation(repository, root)
    active = current_evaluation(root)
    if active is None:
        raise ValueError("Prepare a fresh evaluation for the current protocol first")
    directory, evaluation = active
    live = models is None or any(getattr(m, "requires_live_budget", False) for m in models.values())
    required = tuple("model:" + j + "/" + str(judge_identity(j)["reasoning_effort"] or "none") for j in JUDGES) + ("compute:features","compute:temporal")
    accounting.install(directory / "accounting", budget, require_live=live, required_quotes=required)
    tasks = inventory(repository)
    with RunLock(directory / "evaluation-owner"):
        for position in evaluation["positions"]:
            entry = find(root, position["sample_id"], position["prompt_form"], position["method"], position["seed"])
            available = [entry] + entry.get("candidates", []) if entry else []
            if not any(v["video_sha256"] == position["video_sha256"] for v in available):
                raise ValueError("Frozen evaluation candidate changed")
            task = tasks[position["sample_id"], position["prompt_form"]]
            topic = position["sample_id"] + "__" + position["prompt_form"]
            source = Video(repository / task["source"], directory / "tasks" / topic).info
            if source["sha256"] != position["source_sha256"] or task["request_sha256"] != position["request_sha256"]:
                raise ValueError("Frozen evaluation source/request changed")
            body={"track":position["prompt_form"]}
            reviewed=directory/'evaluation-inputs'/(topic+'.json')
            if reviewed.exists():
                supplement=load(reviewed)
                if supplement.get('source_sha256')!=source['sha256'] or supplement.get('request_sha256')!=task['request_sha256']:
                    raise ValueError('Reviewed task input differs from registered source/request')
                body.update(supplement['body'])
                if body['track']!=position['prompt_form']:raise ValueError('Reviewed input cannot change the registered task track')
            task_plan = freeze_plan(body, task["request"], source, directory / "tasks" / topic)
            candidate = Video(root / position["video"], directory / "tasks" / topic).info
            scope = accounting.scope(directory / "accounting", topic, "independent")
            from evaluation.final_suite import automatic
            measured=automatic(source,candidate,task_plan,directory/'automatic-metrics',accounting_scope=scope)
            for name in JUDGES:
                key = _score_key(position, name)
                link = directory / "scores" / (key + ".json")
                if link.exists():
                    _read_score(directory, link, evaluation)
                    continue
                call = directory / "calls" / key
                accounting.bind(call, scope)
                model = accounting.attach(models[name] if models else make_judge(name), scope)
                try:
                    result = judge_candidate(task["request"], source, candidate, call, model=model, plan=task_plan)
                except ReportUnavailable:
                    result = {"status": "missing", "reason": "report_recovery_exhausted", "report": None,
                        "source_sha256": source["sha256"], "output_sha256": candidate["sha256"]}
                result={**result,'automatic':measured,'track':position['prompt_form']}
                result_path = call / "current-result.json"
                immutable(result_path, result)
                immutable(link, {"evaluation_sha256": evaluation["sha256"], "key": key,
                    "position": position, "judge": name, "result_path": str(result_path.relative_to(directory)),
                    "result_sha256": sha(result_path)})
    compare_evaluation(repository, root, models=models)
    return report(repository, root)


def compare_evaluation(repository, root, *, models=None):
    """Adapt registered positions to the existing randomized/swapped blind suite."""
    from collections import defaultdict
    from evaluation.final_suite import blind_pairs
    from evaluation.low_high import check_plan, freeze_plan, profile
    from evaluation.creative import JUDGES
    from planner_harness.video import Video
    root, repository = Path(root).resolve(), Path(repository).resolve()
    active = current_evaluation(root)
    if active is None:
        raise ValueError("Prepare the current evaluation before comparing")
    directory, evaluation = active
    groups = defaultdict(dict)
    for position in evaluation["positions"]:
        label = position["method"]
        if label in {"full", "none"}:
            label += "_" + position.get("position", "final")
        groups[position["sample_id"], position["prompt_form"], position["seed"]][label] = position
    # Prepared positions retain missing candidates in the comparison denominator.
    for path in (root / "plans").glob("*.json"):
        for position in load(path)["positions"]:
            group = groups[position["sample_id"], position["prompt_form"], position["seed"]]
            labels = [position["method"] + "_first", position["method"] + "_final"] if position["method"] in {"full", "none"} else [position["method"]]
            for label in labels:group.setdefault(label, None)
    for (sample, form, seed), group in groups.items():
        if seed == 42 and any(k in group for k in ("full_final", "none_final", "pe", "planner-once", "direct-best-of-n")):
            group.setdefault("direct", None)
        if "lineage-chain" in group or "lineage-source-restart" in group:
            group.setdefault("lineage-chain", None);group.setdefault("lineage-source-restart", None)
        for method in ("full", "none"):
            if method + "_final" in group:group.setdefault(method + "_first", None)
    contrasts = evaluation["comparison_pairs"]
    tasks = inventory(repository)
    records = []
    with RunLock(directory / "comparison-owner"):
        for (sample, form, seed), positions in sorted(groups.items()):
            pairs = [(a, b) for a, b in contrasts if a in positions and b in positions]
            if not pairs:
                continue
            topic_id = sample + "__" + form
            task = tasks[sample, form]
            source = Video(repository / task["source"], directory / "tasks" / topic_id).info
            plan_path = directory / "tasks" / topic_id / "plan.json"
            plan = check_plan(load(plan_path), task["request"], source) if plan_path.exists() else freeze_plan({"track": form}, task["request"], source, plan_path.parent)
            videos = {label: Video(root / p["video"], directory / "tasks" / topic_id).info for label, p in positions.items() if p}
            output = blind_pairs(repository, directory, {"id": topic_id, "request": task["request"]}, videos,
                judges=models, source_plan=(source, plan), pairs=pairs, media_root=root / "media", write_topic_record=False, retain_unknown=True)
            for judge, rows in output.items():
                for left, right in pairs:
                    label = left + "__to__" + right
                    path = None
                    if left in videos and right in videos:
                        identity = {"source": source["sha256"], "left": videos[left]["sha256"], "right": videos[right]["sha256"],
                            "plan": plan["sha256"], "profile": profile()["sha256"], "judge": judge, "seed": 0}
                        path = directory / "blind-judge" / signature(identity) / "result.json"
                    records.append({"sample_id": topic_id + "__" + str(seed), "source_id": source["sha256"],
                        "length": form, "judge": judge, "comparison": label,
                        "path": str(path.relative_to(directory)) if path else None, "sha256": sha(path) if path else None, "result": rows[label]})
        body = {"evaluation_sha256": evaluation["sha256"], "records": records}
        save(directory / "comparison-index.json", {**body, "sha256": signature(body)})
    return records


def _read_score(directory, path, evaluation):
    link = load(path)
    result_path = (directory / link["result_path"]).resolve()
    if link["evaluation_sha256"] != evaluation["sha256"] or not result_path.is_relative_to(directory) or sha(result_path) != link["result_sha256"]:
        raise ValueError("Active evaluation score binding changed")
    if link["key"] != _score_key(link["position"], link["judge"]) or path.name != link["key"] + ".json":
        raise ValueError("Active evaluation score key changed")
    result = load(result_path)
    if result["source_sha256"] != link["position"]["source_sha256"] or result["output_sha256"] != link["position"]["video_sha256"]:
        raise ValueError("Active evaluation score/video differs")
    return result


def register_plan(root, batch):
    """Only genuinely prepared method positions become missing rows in the view."""
    body = {"schema": VERSION, "positions": [{"sample_id": t["sample_id"], "prompt_form": t["prompt_form"],
        "method": m, "seed": batch["seed_sequence"]["start"]} for t in batch["topics"] for m in batch["arms"]]}
    immutable(Path(root) / "plans" / (signature(body) + ".json"), {**body, "sha256": signature(body)})


def report(repository, root, *, methods=None, seeds=None, splits=None, forms=None):
    root = Path(root).resolve()
    tasks = inventory(repository)
    rows, positions = [], set()
    plans = list((root / "plans").glob("*.json"))
    for path in plans:
        plan = load(path)
        if plan.get("sha256") != signature({k: v for k, v in plan.items() if k != "sha256"}):
            raise ValueError("Registered result plan changed")
        positions.update((p["sample_id"], p["prompt_form"], p["method"], p["seed"]) for p in plan["positions"])
    if not plans or any((root / "entries").glob("*/*/direct/seed-42.json")):
        # The current Direct task is already authorized for all current sources.
        positions.update((sample, form, "direct", 42) for sample, form in tasks)
    positions.update((r["sample_id"], r["prompt_form"], r["method"], r["seed"])
        for r in (verify_entry(root, p) for p in (root / "entries").glob("*/*/*/seed-*.json")))
    for sample, form, method, seed in sorted(positions):
        task = tasks.get((sample, form))
        if not task:
            raise ValueError("Registered result/plan has no current task")
        if (splits and task["split"] not in splits) or (forms and form not in forms) or (methods and method not in methods) or (seeds and seed not in seeds):
            continue
        entry = find(root, sample, form, method, seed)
        if entry and any(entry[k] != task[k] for k in ("source_sha256", "request_sha256")):
            raise ValueError("Registered result differs from current task")
        rows.append({**task, "method": method, "seed": seed,
            "status": "ready" if entry else "missing", "video": entry["video"] if entry else None,
            "video_sha256": entry["video_sha256"] if entry else None, "evaluation_status": "pending",
            "candidates": entry.get("candidates", []) if entry else []})
    from evaluation.final_suite import ratings
    active = current_evaluation(root)
    metric_rows=[]
    for row in rows:
        row["judges"] = {}
        if active and row["video"]:
            directory, evaluation = active
            for identity in evaluation["judges"]:
                name = identity["model"]
                link = directory / "scores" / (_score_key(row, name) + ".json")
                if link.exists():
                    result = _read_score(directory, link, evaluation)
                    row["judges"][name] = {"status": result.get("status", "scored"), "report": result.get("report"),
                        "metrics": ratings(result),
                        "record": str(link.relative_to(root))}
        if active:
            for identity in active[1]['judges']:
                name=identity['model'];link=active[0]/'scores'/(_score_key(row,name)+'.json') if row['video'] else None
                metric_rows.append({'source_id':row['source_sha256'],'sample_id':row['sample_id']+'__'+row['prompt_form']+'__'+str(row['seed']),
                    'length':row['prompt_form'],'judge':name,'variant':row['method'],
                    'result':_read_score(active[0],link,active[1]) if link and link.exists() else None})
        if row["judges"]:
            full = len(row["judges"]) == len(active[1]["judges"])
            missing = any(j["report"] is None or j["status"] == "missing" for j in row["judges"].values())
            row["evaluation_status"] = ("complete_with_missing" if missing else "complete") if full else "partial"
        first = next((c for c in row["candidates"] if "first" in c["roles"]), None)
        if first and row["method"] in {"full", "none"}:
            row["first"] = {**first, "judges": {}}
            first_position = {**row, **first}
            if active:
                for identity in active[1]["judges"]:
                    name = identity["model"]
                    link = active[0] / "scores" / (_score_key(first_position, name) + ".json")
                    result = _read_score(active[0], link, active[1]) if link.exists() else None
                    if result:
                        row["first"]["judges"][name] = {"metrics": ratings(result), "record": str(link.relative_to(root))}
                    metric_rows.append({"source_id": row["source_sha256"], "sample_id": row["sample_id"] + "__" + row["prompt_form"] + "__" + str(row["seed"]),
                        "length": row["prompt_form"], "judge": name, "variant": row["method"] + "_first", "result": result})
    summary = {"schema": VERSION, "planned": len(rows), "ready": sum(r["status"] == "ready" for r in rows),
               "evaluation_status": "current_evaluation" if active else "pending_new_evaluation", "results": rows}
    if active:
        from evaluation.low_high_summary import summarize
        summary['metrics']=summarize(metric_rows)
        index_path = active[0] / "comparison-index.json"
        if index_path.exists():
            index = load(index_path)
            if index.get("evaluation_sha256") != active[1]["sha256"] or index.get("sha256") != signature({k: v for k, v in index.items() if k != "sha256"}):
                raise ValueError("Current blind comparison index changed")
            for record in index["records"]:
                if record["path"] is None:
                    if record["result"].get("status") != "missing" or record["result"].get("judgments") is not None:
                        raise ValueError("Missing blind comparison must remain explicit")
                    continue
                path = (active[0] / record["path"]).resolve()
                if not path.is_relative_to(active[0]) or sha(path) != record["sha256"] or load(path) != record["result"]:
                    raise ValueError("Current blind comparison result changed")
            from evaluation.pairwise import summary as summarize_blind
            summary["blind_comparisons"] = {label: summarize_blind([{**r, "result": r["result"] if r["result"].get("judgments") else None} for r in index["records"] if r["comparison"] == label])
                for label in sorted({r["comparison"] for r in index["records"]})}
    save(root / "results.json", summary)
    body = ['<!doctype html><meta charset="utf-8"><title>LHA 视频结果</title>',
        '<style>body{font:16px system-ui;max-width:1200px;margin:auto;padding:24px}section{border-top:1px solid #ccc;padding:16px 0}video{max-width:100%;max-height:360px}p{white-space:pre-wrap}</style>',
        '<h1>LHA 视频结果</h1><p>已就绪 ' + str(summary["ready"]) + ' / ' + str(summary["planned"]) + '；按当前评价会话显示评分。</p>']
    if summary.get("blind_comparisons"):
        body.append('<details><summary>当前盲比较</summary><pre>' + html.escape(json.dumps(summary["blind_comparisons"], ensure_ascii=False, indent=2)) + '</pre></details>')
    for row in rows:
        body.append('<section><h2>' + html.escape(f'{row["sample_id"]} / {row["prompt_form"]} / {row["method"]} / seed {row["seed"]}') + '</h2><p>' + html.escape(row["request"]) + '</p>')
        body.append('<video controls preload="none" src="' + quote(row["video"], safe="/.") + '"></video><p>' + ('待新评价' if not row["judges"] else '当前评价：' + html.escape(row["evaluation_status"])) + '</p>' if row["video"] else '<p>视频缺失</p>')
        for name, judgment in row["judges"].items():
            body.append('<h3>' + html.escape(name) + '</h3><pre>' + html.escape(json.dumps(judgment.get("metrics") or {"status":judgment["status"]}, ensure_ascii=False, indent=2)) + '</pre>')
        if row.get("first"):
            first = row["first"]
            body.append('<details><summary>首轮 ' + html.escape(first["id"]) + ' / seed ' + str(first["seed"]) + '</summary>')
            body.append('<video controls preload="none" src="' + quote(first["video"], safe="/.") + '"></video>')
            body.append('<pre>' + html.escape(json.dumps(first["judges"] or {"status": "待新评价"}, ensure_ascii=False, indent=2)) + '</pre></details>')
        body.append('</section>')
    (root / "index.html").write_text("\n".join(body), encoding="utf-8")
    return summary
