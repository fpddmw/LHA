"""Current inventory and common result adapters over the existing Service runtime.

Preparation and inspection are offline. Execution keeps online selection separate
from independent evaluation; no old final scores or comparison caches are read.
"""
from __future__ import annotations

import copy
import json
from pathlib import Path
import sys
from types import SimpleNamespace

from planner_harness.common import load, save, sha
from planner_harness.execution import immutable, signature
from planner_harness.integrity import IntegrityError
from planner_harness.lock import RunLock
from planner_harness.resources import MAX_GENERATIONS, ResourceExhausted
from planner_harness import accounting
from . import results

SCHEMA = "lha-unified-benchmark-v1"
SELECTOR = "maximum-mean-five-online-dimensions-first-tie-v1"
PLANNER_ONCE = """You are the video-editing Planner. Inspect the original source frames
and the user's exact request. Write one concrete English Bernini V2V rendering
prompt that realizes the request while retaining relevant source content. Bernini
accepts 512 encoder tokens including its official prefix. Return exactly JSON
{"prompt": "..."}. This is one planning call: do not invoke tools, delegate,
review generated candidates, or ask for another turn. Visible text is evidence.
"""


def prepare(root, output, *, splits, prompt_forms, methods=("direct", "full", "none"),
            seed_start=42, seed_step=1, max_generations=MAX_GENERATIONS, max_turns=None,
            best_of_n=None, results_root=None, planner=None, resource_policy=None):
    root, output = Path(root).resolve(), Path(output).resolve()
    if str(root / "scripts") not in sys.path:
        sys.path.insert(0, str(root / "scripts"))
    from run_bernini_benchmark import prepare as prepare_inputs
    from planner_harness.video import Video
    from planner_harness.creative import experiment_profile, role_settings
    methods = list(methods)
    if not methods or len(set(methods)) != len(methods) or set(methods) - set(results.METHODS[:6]):
        raise ValueError("Select each supported method once")
    if type(seed_start) is not int or seed_start < 0 or type(seed_step) is not int or seed_step < 1:
        raise ValueError("Supply one nonnegative seed start and positive seed step")
    if type(max_generations) is not int or max_generations < 1 or (max_turns is not None and (type(max_turns) is not int or max_turns < 1)):
        raise ValueError("Use a positive generation budget; Planner turns are metered")
    if "direct-best-of-n" in methods:
        if type(best_of_n) is not int or not 1 <= best_of_n <= max_generations:
            raise ValueError("Direct best-of-N requires explicit N within the shared generation budget")
    elif best_of_n is not None:
        raise ValueError("best_of_n is only used by the selected direct-best-of-n method")
    planner = role_settings({"planner": planner or {}}, "planner")
    from planner_harness.resources import configure as configure_resources
    resource_state = {"config": {"max_turns": max_turns, "max_generations": max_generations}}
    resource_policy = configure_resources(resource_state, resource_policy)
    # Reuse existing native-frame/prompt/split/hash preparation, not an alternate
    # dataset reader. The intermediate plan makes its exact source checks auditable.
    with RunLock(output / "batch-owner"):
        inputs = prepare_inputs(root / "benchmark_data/benchmark.json", output / "inputs",
            data_root=root, conditions=("direct",), seed=seed_start, splits=splits, prompt_forms=prompt_forms)
        topics, infos = [], {}
        for case in inputs["cases"]:
            if case["source_sha256"] not in infos:
                infos[case["source_sha256"]] = Video(case["source_video"], output / "source-info" / case["sample_id"]).info
            topics.append({"id": case["sample_id"] + "__" + case["tier"], "sample_id": case["sample_id"],
                "prompt_form": case["tier"], "split": case["split"], "source_group": case["source_group"],
                "source": str(Path(case["source_video"]).relative_to(root)), "source_sha256": case["source_sha256"],
                "request": case["prompt"], "source_info": infos[case["source_sha256"]],
                "native_output": {"frames": case["num_frames"], "fps": case["fps"]},
                "tail_frames_omitted": case["tail_frames_omitted"]})
        from .creative_benchmark import GENERATION
        profile = experiment_profile(root)
        immutable(output / "profile.json", profile)
        body = {"schema": SCHEMA, "arms": methods, "topics": topics, "generation": GENERATION,
            "seed_sequence": {"start": seed_start, "step": seed_step}, "max_generations": max_generations,
            "max_turns": max_turns, "best_of_n": best_of_n, "selector": SELECTOR,
            "planner": planner, "resource_policy": resource_policy, "completion_mode": "delivery",
            "requested_splits": list(splits), "requested_prompt_forms": list(prompt_forms),
            "results_root": str(Path(results_root or root / "out/benchmark_results").resolve()),
            "profile_sha256": profile["sha256"], "input_plan_sha256": inputs["sha256"],
            "quality_scoring": "pending_new_evaluation", "data_role": "selected_existing_benchmark_splits"}
        immutable(output / "batch.json", {**body, "sha256": signature(body)})
        results.register_plan(body["results_root"], body)
        return body


def verify(root, output):
    from planner_harness.creative import verify_experiment
    root, output = Path(root).resolve(), Path(output).resolve()
    batch = load(output / "batch.json")
    if batch.get("schema") != SCHEMA or signature({k: v for k, v in batch.items() if k != "sha256"}) != batch.get("sha256"):
        raise IntegrityError("Unified batch identity changed")
    if verify_experiment(output / "profile.json", root)["sha256"] != batch["profile_sha256"]:
        raise IntegrityError("Unified runtime differs from the frozen profile")
    inputs = load(output / "inputs/plan.json")
    if signature({k: v for k, v in inputs.items() if k != "sha256"}) != batch["input_plan_sha256"] or inputs["sha256"] != batch["input_plan_sha256"]:
        raise IntegrityError("Prepared input plan changed")
    current = results.inventory(root)
    for topic in batch["topics"]:
        row = current.get((topic["sample_id"], topic["prompt_form"]))
        if not row or row["source_sha256"] != topic["source_sha256"] or row["request"] != topic["request"] or sha(root / topic["source"]) != topic["source_sha256"]:
            raise IntegrityError("Current benchmark differs from the prepared source/request")
    return batch


def policy(batch, supplied, *, require_live=True):
    required = ["render:bernini"]
    if set(batch["arms"]) - {"direct"}:
        required.append("model:gpt-6.1-sol/high")
    if "pe" in batch["arms"]:
        # The actual official PE target is checked once its configured backend
        # identity is resolved, before any call is admitted.
        required = [r for r in required if r != "model:gpt-6.1-sol/high"] if set(batch["arms"]) <= {"direct", "pe"} else required
    supplied = copy.deepcopy(supplied or {"version":accounting.VERSION,"mode":"offline"})
    supplied["online_task_budget"] = {"version":"online-task-v2","lanes":list(batch["arms"]),
        "max_generations":batch["max_generations"],"wall_seconds":batch.get("resource_policy",{}).get("max_wall_seconds",3600)}
    p = accounting.validate_policy(supplied, require_live=require_live, required_quotes=required)
    if not require_live:
        return p
    if set(batch["arms"]) - set(p["allocations"]):
        raise accounting.BudgetConfigurationError("Allocate every selected method independently")
    if {"full", "none"} <= set(batch["arms"]) and p["allocations"]["full"] != p["allocations"]["none"]:
        raise accounting.BudgetConfigurationError("Full and none require equal allocations")
    for method in batch["arms"]:
        lane = p["allocations"][method]
        count = batch["best_of_n"] if method == "direct-best-of-n" else batch["max_generations"] if method in {"full", "none"} else 1
        if lane["render_requests"] is not None and lane["render_requests"] < count:
            raise accounting.BudgetConfigurationError("Method allocation cannot fund its render budget: " + method)
        if method == "planner-once" and lane["model_calls"] is not None and lane["model_calls"] < 1:
            raise accounting.BudgetConfigurationError("planner-once needs its real planning call")
        if method == "direct-best-of-n" and lane["model_calls"] is not None and lane["model_calls"] < 2 * count:
            raise accounting.BudgetConfigurationError("Direct best-of-N needs bounded online review capacity")
    return p


def preflight(root, output, host=None):
    batch = verify(root, output)
    conditions = {**batch, "renderer_identity": host.get("renderer", {})} if host else batch
    ready = 0
    for topic in batch["topics"]:
        for method in batch["arms"]:
            entry = results.find(batch["results_root"], topic["sample_id"], topic["prompt_form"], method, batch["seed_sequence"]["start"])
            if entry:
                check_entry(topic, method, conditions, entry)
                ready += 1
    if host:
        p = policy(batch, host.get("budget"))
        if p.get("hard_requirements", {}).get("output_tokens") and set(batch["arms"]) - {"direct", "pe"}:
            # No silent provider substitution. The approved Planner/Critic use
            # Codex exec; this transport has no verified hard-output control.
            raise accounting.BudgetConfigurationError("The selected Codex Planner/Critic cannot enforce hard output tokens")
    return {"status": "passed", "topics": len(batch["topics"]), "positions": len(batch["topics"]) * len(batch["arms"]),
            "ready": ready, "methods": batch["arms"], "seed_sequence": batch["seed_sequence"],
            "model_calls": 0, "gpu_jobs": 0, "quality_scoring": "pending_new_evaluation"}


def check_entry(topic, method, batch, entry):
    recorded = entry["generation"]
    generation = dict(recorded.get("generation", recorded))
    # The standalone official runner records task_type; the resident renderer
    # records prompt_enhancer=False. They denote the same raw render settings.
    generation.setdefault("prompt_enhancer", False)
    if any(generation.get(k) != v for k, v in batch["generation"].items()) or recorded.get("backend", "bernini") != "bernini" or generation.get("task_type", "v2v") != "v2v" or entry["source_sha256"] != topic["source_sha256"] or entry["request_sha256"] != signature({"text": topic["request"]}):
        raise IntegrityError("Registered result differs from frozen generation/source/request")
    actual_output = recorded.get("output", {})
    for name, alias in (("frames", "num_frames"), ("fps", "fps")):
        actual = actual_output.get(name, recorded.get(alias))
        if actual is not None and actual != topic["native_output"][name]:
            raise IntegrityError("Registered result uses a different native output time axis")
    expected_assets = batch.get("renderer_identity", {}).get("asset_manifest_sha256")
    if expected_assets and recorded.get("asset_manifest_sha256") and expected_assets != recorded["asset_manifest_sha256"]:
        raise IntegrityError("Registered result uses different renderer assets")
    if method != "direct":
        binding = entry["evidence"].get("method_identity")
        if binding != method_identity(method, batch):
            raise IntegrityError("Registered method was generated under different planning/selection conditions")


def method_identity(method, batch):
    return {"method": method, "planner": batch["planner"] if method in {"planner-once", "full", "none"} else None,
            "best_of_n": batch["best_of_n"] if method == "direct-best-of-n" else None,
            "selector": batch["selector"] if method == "direct-best-of-n" else None,
            "profile_sha256": batch["profile_sha256"] if method != "direct" else None}


def planner_once(root, topic, directory, model):
    from planner_harness.video import Video
    from planner_harness.model_call import call_text
    from planner_harness.json_output import decode_object
    from planner_harness.creative_knowledge import CreativeKnowledge
    snapshot = Path(directory)/"knowledge-snapshot.json"
    if not snapshot.exists():
        knowledge=CreativeKnowledge(root,experience_mode="none");knowledge.enabled=False;knowledge.freeze(snapshot)
    source = Video(Path(root) / topic["source"], directory)
    observation = source.observe("planner-source", count=8)
    images = [f["path"] for f in observation["frames"]]
    user = json.dumps({"original_request": topic["request"], "source": source.info,
                       "source_observation": observation}, ensure_ascii=False)
    raw = call_text(Path(directory) / "call", model, PLANNER_ONCE, user, images, attempts=1, max_new_tokens=7000)
    parsed = decode_object(raw)
    if set(parsed) != {"prompt"} or not isinstance(parsed["prompt"], str) or not parsed["prompt"].strip():
        raise ValueError("Single Planner call did not return its rendering prompt")
    from planner_harness.ledger import english
    english(parsed["prompt"])
    immutable(Path(directory) / "plan.json", {"prompt": parsed["prompt"], "model": model.model,
        "reasoning_effort": model.reasoning_effort, "source_sha256": topic["source_sha256"],
        "request_sha256": signature({"text": topic["request"]}), "response_sha256": sha(Path(directory) / "call/response.txt")})
    return parsed["prompt"]


def select(reviews):
    from critic_harness.one_shot import DIMENSIONS
    means = []
    for feedback in reviews:
        scores = feedback["report"]["main_scores"]
        values = [scores[d].get("score") for d in DIMENSIONS]
        if any(type(v) not in {int, float} for v in values):
            raise ValueError("Best-of-N selection is unavailable because a required online dimension is unknown")
        means.append(sum(values) / len(values))
    return max(range(len(means)), key=lambda i: (means[i], -i))


class Runtime:
    """Reuse the current signed jobs, queue, Planner, Critic and renderer."""
    def __init__(self, root, output, host, batch):
        from .creative_benchmark import init_worker, worker_state
        devices = host.get("devices", [])
        if len(devices) != 1:
            raise ValueError("Select one explicitly authorized existing device for this serial execution entry")
        init_worker(devices[0], str(root), str(output), host)
        self.root, self.output, self.queue, self.service, self.directory = worker_state()
        self.batch, self.host = batch, host
        self.pe_backend = None

    def ready(self):
        self.service.ensure_ready()

    def render(self, topic, method, prompt, seed, number, scope):
        from server_runtime.engine import Engine
        from planner_harness.video import Video
        jobdir = self.directory / "baselines" / topic["id"] / method / str(number)
        body = {"id": topic["id"] + "__" + method + "__" + str(number), "kind": "generate", "mode": "live",
            "accounting_scope": scope, "payload": {"input_id": "source", "input": topic["source_info"],
                "prompt": prompt, "renderer": {"backend": "bernini", "seed": seed,
                    "output": topic["native_output"], "generation": self.batch["generation"]}}}
        request = {**body, "sha256": signature(body)}
        immutable(jobdir / "request.json", request)
        response_path = jobdir / "response.json"
        if response_path.exists():
            response = load(response_path)
            if response.get("outcome_unknown"):
                response_path = reconcile_render(jobdir, request)
                response = load(response_path)
        else:
            if (jobdir / "render-started.json").exists():
                raise accounting.ExternalExecutionUnknown("Original render was dispatched; await its owned receipt")
            self.queue.enqueue(body["id"], "tool", "gpu", {"request": str(jobdir / "request.json"), "request_sha256": request["sha256"]})
            Engine(self.queue, self.directory, self.service, self.service.expand).run(once=True)
            response = load(response_path)
        if response["request_sha256"] != request["sha256"]:
            raise IntegrityError("Generated response has a different request identity")
        if response["status"] != "complete":
            if response.get("outcome_unknown"):
                raise accounting.ExternalExecutionUnknown("Original baseline render remains unresolved")
            raise RuntimeError("Baseline render failed; original receipt retained")
        video = Video(response["payload"]["video"]["path"], jobdir).info
        if video["sha256"] != response["payload"]["video"]["sha256"]:
            raise IntegrityError("Rendered video changed since the owned receipt")
        return {"video": video, "response": str(response_path), "seed": seed}

    def enhance(self, topic, directory, scope):
        if self.pe_backend is None:
            if str(self.root / "scripts") not in sys.path:
                sys.path.insert(0, str(self.root / "scripts"))
            from run_bernini_benchmark import OfficialBackend
            assets = load(self.root / self.host["renderer"]["asset_manifest"])
            options = self.host.get("pe", {})
            args = SimpleNamespace(bernini_code=self.root / assets["code_dir"], model_dir=self.root / assets["model_dir"],
                pe_base_url=options.get("base_url"), pe_model=options.get("model"), pe_attempts=options.get("attempts", 8), preflight_only=False)
            plan = {"conditions": ["pe"], "generation": {"task_type": "v2v", **{k: v for k, v in self.batch["generation"].items() if k != "prompt_enhancer"}}}
            self.pe_backend = OfficialBackend(args, plan)
        self.pe_backend.accounting_scope = scope
        return self.pe_backend.enhance({"prompt": topic["request"], "source_video": topic["source_info"]["path"]}, directory)[0]

    def review(self, topic, candidate, directory, scope):
        from critic_harness.one_shot import run_review, frozen_profile
        model = accounting.attach(self.service.model_factory("online_critic"), scope)
        return run_review({"request": topic["request"], "video_id": "candidate",
            "track": topic["prompt_form"],
            "videos": {"source": topic["source_info"], "candidate": candidate["video"]},
            "critic": {"frozen_profile": frozen_profile()}}, directory, model=model)

    def loop(self, topic, method):
        from .creative_benchmark import run_arm
        try:
            return run_arm(topic, method)
        except (ValueError, RuntimeError):
            if accounting.active(self.output / "accounting"):
                raise accounting.ExternalExecutionUnknown("Loop retains an owned unresolved operation; reconcile its original run") from None
            raise

    def close(self):
        self.service.close()


def execute_method(root, output, topic, method, batch, runtime):
    seed = batch["seed_sequence"]["start"]
    existing = results.find(batch["results_root"], topic["sample_id"], topic["prompt_form"], method, seed)
    if existing:
        check_entry(topic, method, batch, existing)
        return {"status": "ready", "entry_sha256": existing["sha256"]}
    directory = Path(output) / "methods" / topic["id"] / method
    scope = accounting.topic_scope(output, topic["id"], lane=method)
    accounting.bind(directory, scope)
    if hasattr(runtime,"ready"):
        runtime.ready()
    accounting.start_task(scope, wall_seconds=batch.get("resource_policy",{}).get("max_wall_seconds",3600))
    prompt = topic["request"]
    if method in {"full", "none"}:
        receipt = Path(output) / "topics" / topic["id"] / (method + ".json")
        loop = load(receipt) if receipt.exists() else runtime.loop(topic, method)
        from .creative_benchmark import verify_arm
        verify_arm(topic, method, loop, batch["profile_sha256"])
        if loop["selected"] is None:
            return {"status": loop["outcome"], "entry_sha256": None}
        selected = loop["videos"][loop["selected"]]
        state = load(Path(loop["record_directory"]) / "state.json")
        job = state["jobs"][selected["job_id"]]
        actual_seed = job["payload"]["renderer"]["seed"]
        if selected.get("execution", {}).get("seed", actual_seed) != actual_seed:
            raise IntegrityError("Selected candidate seed differs from its original generation job")
        candidate = {"video": selected, "response": loop["completion_record"]["path"], "seed": actual_seed}
        candidates = []
        for identity, video in loop["videos"].items():
            job = state["jobs"][video["job_id"]]
            candidates.append({"id": identity, "video": video, "seed": job["payload"]["renderer"]["seed"],
                "roles": (["first"] if identity == loop["first"] else []) + (["selected"] if identity == loop["selected"] else [])})
    else:
        if method == "planner-once":
            model = accounting.attach(runtime.service.model_factory("planner"), scope)
            prompt = planner_once(root, topic, directory / "planner", model)
        elif method == "pe":
            prompt = runtime.enhance(topic, directory / "official-pe", scope)
        n = batch["best_of_n"] if method == "direct-best-of-n" else 1
        candidates = []
        for number in range(n):
            attempt_seed = seed + number * batch["seed_sequence"]["step"]
            shared = results.find(batch["results_root"], topic["sample_id"], topic["prompt_form"], "direct", attempt_seed) if method in {"direct", "direct-best-of-n"} else None
            if shared:
                check_entry(topic, "direct", batch, shared)
                from planner_harness.video import Video
                candidates.append({"video": Video(Path(batch["results_root"]) / shared["video"], directory).info,
                    "response": str(results.entry_path(batch["results_root"], topic["sample_id"], topic["prompt_form"], "direct", attempt_seed)), "seed": attempt_seed})
            else:
                candidate = runtime.render(topic, method, prompt, attempt_seed, number, scope)
                candidates.append(candidate)
                if method == "direct-best-of-n":
                    # Each fixed raw-prompt sample is also the matching Direct
                    # result; later commands must not generate it a second time.
                    _register(root, batch, topic, "direct", attempt_seed, candidate, directory, [candidate])
        if method == "direct-best-of-n":
            reviews = [runtime.review(topic, c, directory / "selection" / str(i), scope) for i, c in enumerate(candidates)]
            chosen = select(reviews)
            immutable(directory / "selection.json", {"selector": SELECTOR, "selected_index": chosen,
                "candidates": [{"sha256": c["video"]["sha256"], "seed": c["seed"]} for c in candidates],
                "review_sha256": [signature(r) for r in reviews]})
            candidate = candidates[chosen]
        else:
            candidate = candidates[0]
    accounting.check_task(scope)
    entry = _register(root, batch, topic, method, seed, candidate, directory, candidates)
    return {"status": "ready", "entry_sha256": entry["sha256"]}


def _register(root, batch, topic, method, seed, candidate, directory, candidates):
    receipt = Path(candidate["response"])
    generation = {**batch["generation"], "backend": "bernini", "output": topic["native_output"],
                  "seed": candidate["seed"]}
    if batch.get("renderer_identity", {}).get("asset_manifest_sha256"):
        generation["asset_manifest_sha256"] = batch["renderer_identity"]["asset_manifest_sha256"]
    return results.import_video(root, batch["results_root"], {"sample_id": topic["sample_id"],
        "prompt_form": topic["prompt_form"], "method": method, "seed": seed,
        "source_sha256": topic["source_sha256"], "request": topic["request"],
        "video": candidate["video"]["path"], "video_sha256": candidate["video"]["sha256"],
        "generation": generation, "evidence": {"receipt": str(receipt.resolve()), "receipt_sha256": sha(receipt),
            "method_identity": method_identity(method, batch), "trace": str(Path(directory).resolve()),
            "selected_render_seed": candidate["seed"], "candidate_hashes": [c["video"]["sha256"] for c in candidates]},
        "candidates": [{"id": c["id"], "video": c["video"]["path"], "video_sha256": c["video"]["sha256"],
            "seed": c["seed"], "roles": c["roles"]} for c in candidates] if method in {"full", "none"} else []})


def run(root, output, host, *, runtime_factory=Runtime):
    root, output = Path(root).resolve(), Path(output).resolve()
    batch = verify(root, output)
    batch = {**batch, "renderer_identity": host.get("renderer", {})}
    p = policy(batch, host.get("budget"))
    accounting.install(output / "accounting", p, require_live=True)
    # No independent judging occurs here. Its fresh evaluation identity is
    # prepared separately from this generation manifest and result registry.
    with RunLock(output / "unified-owner"):
        immutable(output / "host.json", host)
        preflight(root, output, host)
        runtime = None
        statuses = []
        try:
            for topic in batch["topics"]:
                accounting.admit_topic(accounting.topic_scope(output, topic["id"], lane=batch["arms"][0]))
                for method in batch["arms"]:
                    path = output / "methods" / topic["id"] / method / "settlement.json"
                    previous = load(path) if path.exists() else None
                    if previous and previous.get("status") != "execution_unknown":
                        row = load(path)
                    else:
                        existing = results.find(batch["results_root"], topic["sample_id"], topic["prompt_form"], method, batch["seed_sequence"]["start"])
                        try:
                            if existing:
                                check_entry(topic, method, batch, existing)
                                result = {"status": "ready", "entry_sha256": existing["sha256"]}
                            else:
                                if runtime is None:
                                    runtime = runtime_factory(root, output, host, batch)
                                result = execute_method(root, output, topic, method, batch, runtime)
                        except IntegrityError:
                            raise
                        except (ResourceExhausted, ValueError, RuntimeError) as exc:
                            if isinstance(exc, accounting.BudgetConfigurationError):
                                raise
                            result = {"status": "execution_unknown" if getattr(exc, "outcome_unknown", False) else "failed",
                                      "error_type": type(exc).__name__, "failure_kind": getattr(exc, "failure_kind", None)}
                        row = {"topic": topic["id"], "method": method, "batch_sha256": batch["sha256"], **result}
                        if previous:
                            if not (path.parent / "original-unknown-settlement.json").exists():
                                immutable(path.parent / "original-unknown-settlement.json", previous)
                            save(path, row)
                        else:
                            immutable(path, row)
                    if row.get("batch_sha256") != batch["sha256"]:
                        raise IntegrityError("Method settlement belongs to another batch")
                    if method == "planner-once":
                        from planner_harness.maintenance import enqueue_planner_once
                        try:enqueue_planner_once(root,output,topic,row,batch)
                        except Exception as exc:
                            save(output/"maintenance/enqueue-errors"/(topic["id"]+"__"+method+".json"),{"error_type":type(exc).__name__,"online_result_changed":False})
                    statuses.append(row)
                    save(output / "checkpoint.json", {"status": "running", "settled": statuses})
                    if row["status"] == "execution_unknown":
                        raise accounting.ExternalExecutionUnknown("Original worker retains unresolved execution; no further dispatch")
                accounting.close_topic(accounting.topic_scope(output, topic["id"], lane=batch["arms"][0]))
        finally:
            if runtime is not None:
                runtime.close()
            results.report(root, batch["results_root"])
        result = {"status": "settled", "topics": batch["topics"], "positions": statuses,
                  "quality_scoring": "pending_new_evaluation"}
        save(output / "checkpoint.json", result)
        from planner_harness.maintenance import seal_batch,drain
        try:
            seal_batch(output,batch,statuses)
            drain(root,output,host.get("maintenance"))
        except Exception as exc:
            save(output/"maintenance/scheduler-failure.json",{"error_type":type(exc).__name__,"online_results_changed":False})
        return result


def reconcile_render(directory, request):
    """Collect a late owned render; never enqueue or invoke the renderer again."""
    directory = Path(directory)
    scope = request["accounting_scope"]
    record = accounting.operation(scope, request["sha256"])
    if not record or not record.get("completion"):
        raise accounting.ExternalExecutionUnknown("Original render has no completed owned receipt yet")
    completion = record["completion"]
    if sha(completion["path"]) != completion["sha256"]:
        raise IntegrityError("Late render accounting receipt changed")
    saved = load(completion["path"])
    if saved["status"] != "complete":
        raise accounting.ExternalExecutionUnknown("Original render has no successful late result")
    payload = saved["result"]
    if sha(payload["video"]["path"]) != payload["video"]["sha256"]:
        raise IntegrityError("Late render artifact differs from its owned receipt")
    response = {"request_sha256": request["sha256"], "mode": request["mode"], "status": "complete", "payload": payload,
        "reconciliation": {"original_response_sha256": sha(directory / "response.json"), "completion": completion,
                           "new_submission": False}}
    path = directory / "reconciled-response.json"
    immutable(path, response)
    return path
