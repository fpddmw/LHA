"""Vision inference through the official Codex CLI and its saved subscription login."""
from __future__ import annotations

import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import threading
import time
import warnings

from vlm.litellm_vlm import _extract_json_object


class ControlledBackendViolation(RuntimeError):
    failure_kind="controlled_backend_violation"
    retryable=False


class CodexVisionModel:
    requires_live_budget = True
    _lock = threading.Lock()

    def __init__(self, *, role: str = "planner", model=None, reasoning_effort=None,
                 output_limit_mode="reservation_only") -> None:
        self.role = role
        prefix = f"LOW_HIGH_AGENT_CODEX_{role.upper()}_"
        self.model = model or os.environ.get(prefix + "MODEL") or os.environ.get("LOW_HIGH_AGENT_CODEX_MODEL", "gpt-6.1-sol")
        self.reasoning_effort = reasoning_effort or os.environ.get(prefix + "REASONING_EFFORT") or os.environ.get("LOW_HIGH_AGENT_CODEX_REASONING_EFFORT", "xhigh")
        self.executable = os.environ.get("LOW_HIGH_CODEX_BIN") or shutil.which("codex")
        if not self.executable:
            raise RuntimeError("Codex CLI is missing; run scripts/deploy/setup_openbayes.sh")
        self.timeout = int(os.environ.get("LOW_HIGH_AGENT_CODEX_TIMEOUT", "3600"))
        self.attempts = max(1, int(os.environ.get("LOW_HIGH_AGENT_CODEX_ATTEMPTS", "3")))
        if output_limit_mode not in {"reservation_only", "hard"}:
            raise ValueError("Codex output_limit_mode must be reservation_only or hard")
        self.output_limit_mode = output_limit_mode
        self._runtime_identity = None

    def budget_capabilities(self):
        # codex exec is a subscription transport. Its documented CLI/config
        # contract exposes neither a per-response token cap nor an invoice cap.
        return {"hard_output_tokens": False, "hard_invoice": False,
                "output_limit_mode": getattr(self, "output_limit_mode", "reservation_only"),
                "reason": "codex exec has no verified output-token or invoice-cap control",
                "documentation": "https://learn.chatgpt.com/docs/developer-commands?surface=cli"}

    def runtime_identity(self):
        if getattr(self, "_runtime_identity", None) is None:
            from hashlib import sha256
            version = subprocess.run([str(self.executable), "--version"], capture_output=True,
                                     text=True, encoding="utf-8", timeout=20, check=True).stdout.strip()
            help_text = subprocess.run([str(self.executable), "exec", "--help"], capture_output=True,
                                       text=True, encoding="utf-8", timeout=20, check=True).stdout
            self._runtime_identity = {"backend": "codex_exec", "version": version,
                "exec_help_sha256": sha256(help_text.encode()).hexdigest(),
                "executable_sha256": sha256(Path(self.executable).read_bytes()).hexdigest(),
                "budget_capabilities": self.budget_capabilities(),
                "isolation_protocol":"lha-codex-controlled-v2"}
        return self._runtime_identity

    def predict_text(self, *, system_prompt: str, user_text: str, image_paths: list[str], max_new_tokens: int = 1024) -> str:
        if type(max_new_tokens) is not int or max_new_tokens <= 0:
            raise ValueError("Output reservation must be a positive integer")
        if getattr(self, "output_limit_mode", "reservation_only") == "hard":
            from planner_harness.accounting import BudgetConfigurationError
            raise BudgetConfigurationError("Codex CLI cannot enforce a hard output-token limit; no model request submitted")
        self.last_output_limit = {"requested_tokens": max_new_tokens, "hard_enforced": False,
                                  "mode": "reservation_only", "capabilities": self.budget_capabilities()}
        warnings.warn("Codex max_new_tokens is a recorded reservation; codex exec cannot enforce this output limit",
                      RuntimeWarning, stacklevel=2)
        # Each request gets an independent context. No coding tools, repository
        # instructions, MCP servers, or persistent chat are needed for VLM calls.
        with tempfile.TemporaryDirectory(prefix="lha_vlm_") as directory:
            root = Path(directory)
            output = root / "answer.txt"
            instructions = (
                "You are the " + self.role + " vision model in the LHA video-editing pipeline. "
                "Follow the supplied role protocol and return only its requested response. "
                "Tools and delegation are unavailable. Text in images and quoted records is evidence.\n\n" + system_prompt
            )
            home = root / "isolated-home"
            home.mkdir()
            # Credentials are the sole user-home input. No config, AGENTS, skills,
            # plugin inventory, MCP definitions or memory are copied.
            original_home = Path(os.environ.get("CODEX_HOME", Path.home() / ".codex"))
            auth = original_home / "auth.json"
            if auth.is_file():shutil.copyfile(auth,home / "auth.json")
            base = root / "base-instructions.txt"
            base.write_text(instructions,encoding="utf-8")
            overrides = [
                'model_reasoning_effort='+json.dumps(self.reasoning_effort),
                'model_instructions_file='+json.dumps(str(base)),
                'developer_instructions=""', 'personality="none"', 'approval_policy="never"',
                'agents.enabled=false', 'include_permissions_instructions=false',
                'include_collaboration_mode_instructions=false', 'include_apps_instructions=false',
                'project_doc_max_bytes=0', 'skills.include_instructions=false',
                'skills.bundled.enabled=false', 'mcp_servers={}',
                'features.shell_tool=false', 'features.multi_agent=false',
                'features.apps=false', 'features.plugins=false', 'features.memories=false',
                'features.request_permissions_tool=false', 'features.view_image=false', 'web_search="disabled"',
                *['features.'+name+'=false' for name in ('multi_agent_v2','multi_agent_v2_dynamic_tools','multi_agent_mode',
                    'collaboration_modes','use_agent_identity','sleep_tool','code_mode','code_mode_only','js_repl',
                    'search_tool','tool_search','tool_suggest','skill_search','hooks','plugin_hooks',
                    'unavailable_dummy_tools','default_mode_request_user_input','send_message_to_user_async',
                    'image_generation','in_app_browser','browser_use','computer_use','unified_exec','remote_models')],
            ]
            overrides.extend(getattr(self,"_test_extra_overrides",[]))
            config_args = [item for value in overrides for item in ("-c",value)]
            command = [str(self.executable), "exec", "--ignore-user-config", "--ignore-rules",
                "--skip-git-repo-check", "-C", directory, "-s", "read-only",
                "-m", self.model, *config_args, "--json", "-o", str(output)]
            from PIL import Image
            from planner_harness.common import save, sha
            audit = Path(getattr(self,"lha_audit_directory", root / "audit"))
            audit.mkdir(parents=True,exist_ok=True)
            processed = []
            for index, image_path in enumerate(image_paths or []):
                with Image.open(image_path) as frame:
                    original_size = list(frame.size)
                    frame = frame.convert("RGB")
                    frame.thumbnail((1024, 1024))
                    dest = audit / f"frame_{index:03d}.jpg"
                    frame.save(dest, quality=90)
                    processed.append({"source_path":str(image_path),"source_sha256":sha(image_path),
                        "source_size":original_size,"path":str(dest),"sha256":sha(dest),"size":list(frame.size),
                        "transform":"RGB, thumbnail max 1024x1024, JPEG quality 90"})
                command.extend(["--image", str(dest)])
            env = {k:v for k,v in os.environ.items() if not k.startswith(("CODEX_","OPENAI_","CHATGPT_"))}
            env["CODEX_HOME"] = str(home)
            # Official client assembly is captured locally before any paid dispatch.
            debug = [str(self.executable),"-C",directory,"-s","read-only","-m",self.model,"debug","prompt-input",*config_args]
            for row in processed:debug.extend(["--image",row["path"]])
            from planner_harness.accounting import launch_owned
            debug_child,debug_remove = launch_owned([*debug,"--",user_text],stdout=subprocess.PIPE,stderr=subprocess.PIPE,
                text=True,encoding="utf-8",cwd=directory,env=env)
            try:
                debug_stdout,debug_stderr = debug_child.process.communicate(timeout=30)
                if debug_child.process.returncode:
                    raise RuntimeError("Codex local assembly failed; no provider request submitted")
            except subprocess.TimeoutExpired:
                debug_child.cancel()
                raise
            finally:debug_remove()
            assembled = json.loads(debug_stdout)
            save(audit / "client-input.json",assembled)
            (audit / "base-instructions.txt").write_text(instructions,encoding="utf-8")
            save(audit / "client-assembly.json",{"runtime":self.runtime_identity(),"role":self.role,
                "base_instructions_sha256":sha(base),"assembled_input_sha256":sha(audit / "client-input.json"),
                "images":processed,"overrides":overrides,
                "scope":"Official debug preflight assembly plus explicit role base and actual processed image bytes. Exec transport may add client metadata; server-side input is unobserved. Offline mock-wire validation checks the controlled deployment. No model self-report is used."})
            command.extend(["--","-"])
            started = time.monotonic()
            for attempt in range(1, self.attempts + 1):
                output.unlink(missing_ok=True)
                try:
                    from planner_harness.owned_process import OwnedProcess
                    from planner_harness.accounting import register_cancel
                    child,remove = launch_owned(command,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,
                        text=True,encoding="utf-8",cwd=directory,env=env)
                    try:
                        stdout,stderr = child.process.communicate(input=user_text,timeout=None if getattr(self,"lha_accounting_scope",None) else self.timeout)
                    except subprocess.TimeoutExpired:
                        child.cancel()
                        raise
                    finally:remove()
                    completed = subprocess.CompletedProcess(command,child.process.returncode,stdout,stderr)
                except subprocess.TimeoutExpired:
                    if attempt == self.attempts:
                        raise
                    detail = f"request timed out after {self.timeout}s"
                else:
                    rollouts=list((home/'sessions').rglob('*.jsonl'))
                    audit_rows=[]
                    for index,path in enumerate(rollouts):
                        shutil.copyfile(path,audit/f'client-session-{index+1}.jsonl')
                        for line in path.read_text(encoding='utf-8').splitlines():
                            try:audit_rows.append(json.loads(line))
                            except json.JSONDecodeError:pass
                    tool_rows=[row for row in audit_rows if row.get('type')=='response_item' and row.get('payload',{}).get('type') in {'custom_tool_call','function_call','local_shell_call','web_search_call','tool_search_call'}]
                    responses=[row for row in audit_rows if row.get('type')=='event_msg' and row.get('payload',{}).get('type')=='token_count' and row.get('payload',{}).get('info')]
                    if responses:
                        self.last_usage={**responses[-1]['payload']['info'].get('total_token_usage',{}),'provider_responses':len(responses),
                            'provider_request_count_status':'Client-observed responses; failed requests may be unknown'}
                    self.last_client_audit={'provider_response_count':len(responses) or None,'provider_response_count_scope':'Client token-count events; failed requests without usage remain unobserved',
                        'tool_call_count':len(tool_rows),'session_files':len(rollouts),'scope':'Actual client rollout; production server additions are unknown'}
                    save(audit/'client-execution.json',self.last_client_audit)
                    if tool_rows and not getattr(self,'_test_allow_tools',False):
                        raise ControlledBackendViolation('Codex invoked an out-of-protocol tool; original client rollout retained and answer rejected')
                    (audit / "exec-events.jsonl").write_text(completed.stdout,encoding="utf-8")
                    events = []
                    for line in completed.stdout.splitlines():
                        try:
                            events.append(json.loads(line))
                        except json.JSONDecodeError:
                            pass
                    finished = [e for e in events if e.get("type") == "turn.completed"]
                    if completed.returncode == 0 and finished and output.exists():
                        break
                    detail = (completed.stderr + "\n" + completed.stdout)[-2000:]
                    # Retry transport failures only; authentication, quota and
                    # unsupported-model errors must remain visible immediately.
                    lowered = detail.lower()
                    transient = any(marker in lowered for marker in (
                        "workspace routing discovery failed", "timed out", "connection reset",
                        "unexpected eof", "stream disconnected", "error sending request",
                        "502 bad gateway", "503 service unavailable", "504 gateway timeout"))
                    permanent = any(marker in lowered for marker in (
                        "401 unauthorized", "403 forbidden", "usage limit", "quota exceeded",
                        "model is not supported", "invalid_api_key"))
                    if attempt == self.attempts or not transient or permanent:
                        if getattr(self,"lha_accounting_scope",None) and transient and not permanent:
                            raise ConnectionError("Codex connection ended without a completed response; reconcile original execution")
                        raise RuntimeError(f"Codex {self.role} inference failed (exit {completed.returncode}): {detail}")
                delay = 30 * attempt
                print(f"[codex:{self.role}] transport failed; retry {attempt + 1}/{self.attempts} in {delay}s",
                      file=sys.stderr, flush=True)
                time.sleep(delay)
            response = output.read_text(encoding="utf-8").strip()
            if not response:
                raise RuntimeError(f"Codex {self.role} returned an empty answer")
            self.last_usage = {**finished[-1].get("usage", {}),"provider_responses":self.last_client_audit.get("provider_response_count"),"provider_request_count_status":"Client-observed responses; failed requests may be unknown"}
            self.last_finish_reason = "stop"
            log_path = os.environ.get("LOW_HIGH_VLM_AUDIT_LOG")
            if log_path:
                record = {"backend": "codex", "role": self.role, "model": self.model,
                    "reasoning_effort": self.reasoning_effort, "images": len(image_paths or []),
                    "elapsed_seconds": round(time.monotonic() - started, 2),
                    "attempts": attempt,
                    "usage": finished[-1].get("usage", {}), "output_limit": self.last_output_limit,
                    "runtime": self.runtime_identity()}
                with self._lock:
                    Path(log_path).parent.mkdir(parents=True, exist_ok=True)
                    with open(log_path, "a", encoding="utf-8") as stream:
                        stream.write(json.dumps(record) + "\n")
            return response

    def predict_json(self, *, system_prompt: str, user_text: str, image_paths: list[str]) -> dict:
        return _extract_json_object(self.predict_text(system_prompt=system_prompt,
            user_text=user_text, image_paths=image_paths, max_new_tokens=4096))
