"""Experiment-only availability switch around the unmodified frozen PlannerHarness."""
import json
from pathlib import Path
from planner_harness import PlannerHarness
from planner_harness.common import save, sha

BASE=Path(__file__).resolve().parent
SNAPSHOT=BASE/'snapshot'
BLOCKED={'browse','search','read','view_reference'}


def no_knowledge_operations():
    original=(SNAPSHOT/'src/planner_harness/OPERATIONS.md').read_text(encoding='utf-8')
    paragraphs=original.split('\n\n')
    result=[]
    for paragraph in paragraphs:
        if paragraph.startswith('Your continuing task includes'):
            result.append('Your continuing task includes notes, prior operations and available videos. '
                          'There is no required sequence, reading quota, diagnostic form, fixed design outline or mandatory question tree. Ordinary activities need no invented plot.')
            continue
        if paragraph.startswith('Read results include'):
            continue
        paragraph=paragraph.replace('{"action":"read","arguments":{"targets":[{"id":"choose-editing-input"}]}}',
                                    '{"action":"observe","arguments":{}}')
        paragraph=paragraph.replace('borrowed knowledge and your own choices','your own choices')
        paragraph=paragraph.replace(' A run\'s reading snapshot isolates it from later shared experience revisions.', '')
        paragraph=paragraph.replace(' Shared knowledge is not edited by task tools; experience-update proposals are reviewed separately.', '')
        lines=[line for line in paragraph.splitlines() if not any(line.startswith('| `'+name+'` |') for name in BLOCKED)]
        result.append('\n'.join(lines))
    return '\n\n'.join(result)


class NoKnowledge:
    def freeze(self,path):
        save(path,{'manifest':{},'experiences':[],'documents':{},'asset_hashes':{}})
    def browse(self,*args,**kwargs):
        return {'status':'unavailable'}
    def denied(self,*args,**kwargs):
        raise ValueError('This material-access tool is unavailable in this run.')
    read=search=resolve=denied


class AblationHarness(PlannerHarness):
    def __init__(self,output,model,*,arm):
        assert arm in ('full_knowledge','no_knowledge')
        self.arm=arm
        super().__init__(output,model,root=SNAPSHOT)
        if arm=='no_knowledge':self.knowledge=NoKnowledge()

    def apply_availability(self):
        if self.arm=='no_knowledge':
            self.knowledge=NoKnowledge()
            self.system=no_knowledge_operations()
            (self.output/'system-prompt.txt').write_text(self.system,encoding='utf-8')
            self.state['system_prompt_sha256']=sha(self.output/'system-prompt.txt')
            assert not self.state['reads'] and not self.state.get('reference_image')
        save(self.output/'availability-policy.json',{'arm':self.arm,
             'external_knowledge_enabled':self.arm=='full_knowledge',
             'blocked_tools':sorted(BLOCKED) if self.arm=='no_knowledge' else [],
             'generic_observation_and_output_protocol_retained':True,
             'adapter_sha256':sha(Path(__file__)), 'system_prompt_sha256':sha(self.output/'system-prompt.txt')})

    def run(self):
        self.apply_availability()
        return super().run()

    def context(self):
        text,images,mapping=super().context()
        if self.arm=='no_knowledge':
            payload=json.loads(text)
            payload.pop('knowledge_entrances',None)
            payload.pop('read_receipts',None)
            assert not payload['evaluations'] and set(payload['videos'])=={'source'}
            assert all(item.get('video_id')=='source' for item in mapping)
            text=json.dumps(payload,ensure_ascii=False,indent=2)
        return text,images,mapping

    def operate(self,response,event_id):
        if self.arm=='no_knowledge' and response.get('action') in BLOCKED:
            raise ValueError('This material-access tool is unavailable in this run.')
        return super().operate(response,event_id)


def audit_run(output,arm):
    output=Path(output)
    state=json.loads((output/'state.json').read_text(encoding='utf-8'))
    calls=[]
    for path in sorted((output/'calls').glob('*/input.json')):
        data=json.loads(path.read_text(encoding='utf-8'));payload=json.loads(data['user_text'])
        if arm=='no_knowledge':
            assert 'knowledge_entrances' not in payload and 'read_receipts' not in payload
            assert set(payload['videos'])=={'source'} and not payload['evaluations']
            assert data['system_prompt']==no_knowledge_operations()
            assert all(item.get('video_id')=='source' for item in data['images'])
        calls.append({'input':str(path.relative_to(output)).replace('\\','/'),'sha256':sha(path),
                      'images':len(data['images']),'context_chars':len(data['system_prompt'])+len(data['user_text'])})
    if arm=='no_knowledge':
        assert not state['reads'] and not state.get('reference_image')
        assert not json.loads((output/'knowledge-snapshot.json').read_text(encoding='utf-8'))['documents']
        assert all(e['status']!='ok' for e in state['events'] if e.get('request',{}).get('action') in BLOCKED)
    result={'arm':arm,'status':state['status'],'calls':calls,'read_count':len(state['reads']),
            'model_visible_inputs_saved':True,'no_knowledge_boundary_passed':True if arm=='no_knowledge' else None,
            'scope':'Checks supplied context and tool access; model pretrained knowledge is not removed.'}
    save(output/'model-visible-audit.json',result)
    return result
