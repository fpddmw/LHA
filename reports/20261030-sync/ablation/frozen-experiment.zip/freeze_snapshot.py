import hashlib,json,sys
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parents[3]
DEST=Path(__file__).resolve().parent
SNAPSHOT=DEST/'snapshot'
sys.path[:0]=[str(ROOT/'out/planner_harness/_deps'),str(ROOT/'src')]
from planner_harness.knowledge import Knowledge
assert not (DEST/'freeze.json').exists(), 'Reuse existing frozen snapshot'
knowledge=Knowledge(ROOT)
paths=set()
for folder in ['src/planner_harness','src/vlm']:
    paths.update(p.relative_to(ROOT).as_posix() for p in (ROOT/folder).glob('*') if p.is_file() and p.suffix in ['.py','.md'])
paths.update(['scripts/run_planner_harness.py','scripts/verify_planner_run.py','knowledge/source-map.json'])
if (ROOT/'knowledge/experience/catalog.json').exists():paths.add('knowledge/experience/catalog.json')
for relative in knowledge.paths:
    p=ROOT/relative
    if p.is_file() and p.suffix.lower() in ['.md','.json','.py','.html','.txt','.jpg','.jpeg','.png','.webp']:paths.add(relative)
samples={s['sample_id']:s for s in json.loads((ROOT/'benchmark_data/all_samples.json').read_text(encoding='utf-8'))}
tasks=[]
for sid,track in [('041','short'),('027','short'),('024','long'),('fewshot_004','long')]:
    s=samples[sid];paths.add(s['source_video'])
    tasks.append({'task_id':sid+'__'+track,'sample_id':sid,'track':track,'source_video':s['source_video'],
                  'source_sha256':s['source_video_sha256'],'user_requirement':s['prompt_'+track],
                  'seed':42,'development_exposed':True})
records=[]
for relative in sorted(paths):
    original=ROOT/relative;data=original.read_bytes();target=SNAPSHOT/relative
    target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
    records.append({'path':relative,'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
for row in records:
    assert hashlib.sha256((ROOT/row['path']).read_bytes()).hexdigest()==row['sha256'],'Source changed during capture'
for task in tasks:
    assert hashlib.sha256((SNAPSHOT/task['source_video']).read_bytes()).hexdigest()==task['source_sha256']
fingerprint=hashlib.sha256(json.dumps(records,sort_keys=True).encode()).hexdigest()
def save(name,data):
    (DEST/name).write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
save('freeze.json',{'schema_version':1,'frozen_utc':datetime.now(timezone.utc).isoformat(),
    'files':records,'snapshot_sha256':fingerprint,'total_bytes':sum(x['bytes'] for x in records),
    'source_stable_during_capture':True,'model':'gpt-6.1-sol','reasoning_effort':'xhigh',
    'max_turns':24,'max_context_chars':180000,'mode':'plan','target_model':'unspecified',
    'source_observation_policy':'Same frozen Video implementation, initial overview and optional observe/crop tools; no imported videos.'})
save('tasks.json',tasks)
historical=['out/planner_harness/20261029/041_storybook','out/planner_harness/20261029/004_space_arena',
            'out/planner_harness/20261029_comparison/027_etching','out/planner_harness/20261029_comparison/024_glitch']
current={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (SNAPSHOT/'src/planner_harness').glob('*') if p.is_file() and p.suffix in ['.py','.md']}
audits=[]
for prior in historical:
    old=json.loads((ROOT/prior/'state.json').read_text(encoding='utf-8'))['runtime_sources']
    changed=[k for k in sorted(set(current)|set(old)) if current.get(k)!=old.get(k)]
    audits.append({'prior_run':prior,'runtime_differences':changed,'eligible_for_reuse':False,
        'reason':'Historical runtime/knowledge are not proven identical; use a new matched full arm.'})
save('historical-reuse-audit.json',audits)
save('status.json',{'status':'snapshot_frozen_preparing_adapter','snapshot_sha256':fingerprint,'planned_new_videos':16,
    'runs':[{'task_id':t['task_id'],'arm':a,'planning_status':'pending',
             'renders':{'bernini':'waiting_for_plan_and_gpu','ditto':'waiting_for_plan_and_gpu'}}
            for t in tasks for a in ['full_knowledge','no_knowledge']],
    'formal_evaluation_owner':'separate session','authorization':{'source_thread':'01a1862f-9d81-7921-ab98-4fc1ac212c3c',
    'verified_user_message':'你可以先让消融实验跑起来安排好任务（交给4090部署方案3去做吧，它那边有定时任务），就是无知识库的，然后你这边主持评价。你的方案没问题'}})
print(json.dumps({'files':len(records),'bytes':sum(x['bytes'] for x in records),
                  'snapshot_sha256':fingerprint,'historical_runtime_changed':[bool(x['runtime_differences']) for x in audits]}))
