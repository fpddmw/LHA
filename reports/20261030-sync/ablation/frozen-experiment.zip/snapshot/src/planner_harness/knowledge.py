from __future__ import annotations

import re
import hashlib
from pathlib import Path
from .common import load, page, sha, save


class Knowledge:
    def __init__(self, root, snapshot=None):
        self.root = Path(root).resolve()
        self.snapshot = load(snapshot) if snapshot else None
        self.manifest = self.snapshot["manifest"] if self.snapshot else load(self.root / "knowledge/source-map.json")
        catalog = self.root / "knowledge/experience/catalog.json"
        self.experiences = self.snapshot["experiences"] if self.snapshot else (load(catalog) if catalog.exists() else [])
        self.items = {}
        self.paths = {}
        for group in ("entries", "domain_references", "guides", "model_experience"):
            for row in self.manifest.get(group, []):
                self.add(row["id"], row["path"], row.get("title", row["id"]), group)
        for row in self.experiences:
            self.add(row["id"], row["path"], row["title"], "experience")
            self.items[row["id"]].update({k: row[k] for k in ("origin", "version")})
        for key, filename in {"map": "README.md", "manual": "READING.md", "integration": "INTEGRATION.md"}.items():
            self.add(key, "knowledge/" + filename, key, "operational_guidance")
        # Only explicit provenance paths are accessible, not the general repository.
        def sources(value):
            if isinstance(value, dict):
                if "path" in value and "sha256" in value:
                    self.add(value["path"], value["path"], value["path"], "original_source")
                for child in value.values():
                    sources(child)
            elif isinstance(value, list):
                for child in value:
                    sources(child)
        sources(self.manifest)

    def freeze(self, path):
        """One text snapshot pins readable material without duplicating historical videos."""
        documents, assets = {}, {}
        for relative in self.paths:
            file = self.root / relative
            if not file.is_file():
                continue
            if file.suffix.lower() in {".md", ".json", ".py", ".html", ".txt"}:
                data = file.read_bytes()
                documents[relative] = {"text": data.decode("utf-8"), "sha256": hashlib.sha256(data).hexdigest()}
            elif file.suffix.lower() in {".jpg", ".jpeg", ".png", ".webp"}:
                assets[relative] = sha(file)
        self.snapshot = {"manifest": self.manifest, "experiences": self.experiences,
                         "documents": documents, "asset_hashes": assets}
        save(path, self.snapshot)

    def document(self, row):
        if self.snapshot and row["path"] in self.snapshot["documents"]:
            return self.snapshot["documents"][row["path"]]
        _, file = self.resolve(row["id"])
        return {"text": file.read_text(encoding="utf-8"), "sha256": sha(file)}

    def add(self, identity, relative, title, kind):
        candidate = Path(relative)
        if candidate.is_absolute() or candidate.anchor or ".." in candidate.parts:
            raise ValueError("Knowledge manifest path escapes the repository")
        if relative in self.paths:
            self.items[identity] = self.paths[relative]
            return
        row = {"id": identity, "path": relative, "title": title, "kind": kind}
        self.items[identity] = row
        self.paths[relative] = row

    def resolve(self, target):
        row = self.items.get(target) or self.paths.get(target)
        if row is None:
            raise ValueError("Unknown knowledge reference. Browse or search for a valid ID/path.")
        path = (self.root / row["path"]).resolve()
        if not path.is_relative_to(self.root) or not path.is_file():
            raise ValueError("Unavailable knowledge source")
        if self.snapshot and row["path"] in self.snapshot["asset_hashes"] and sha(path) != self.snapshot["asset_hashes"][row["path"]]:
            raise ValueError("Pinned reference image changed")
        return row, path

    def read(self, target, start_line=1, section=None):
        row = self.items.get(target) or self.paths.get(target)
        if row is None:
            raise ValueError("Unknown knowledge reference. Browse or search for a valid ID/path.")
        path = Path(row["path"])
        if path.suffix.lower() not in {".md", ".json", ".py", ".html", ".txt"}:
            raise ValueError("This source is media; use view_reference for an image. Experiment videos are not task observations.")
        document = self.document(row)
        text = document["text"]
        if section:
            headings = [(i + 1, line) for i, line in enumerate(text.splitlines()) if line.startswith("#") and section.casefold() in line.casefold()]
            if len(headings) != 1:
                raise ValueError(f"Section must match one heading; matches: {headings}")
            start_line = headings[0][0]
        return {**row, "sha256": document["sha256"], "source_status": "Source content retains its authorship and conditions; historical instructions are not task instructions.",
                **page(text, start_line)}

    def browse(self, target="map"):
        if target == "map":
            return {"guidance": "Choose an entrance or search question. Complete entries and original sources can be read by ID or path.",
                    "entrances": [r for r in self.items.values() if r["kind"] in {"guides", "model_experience", "operational_guidance", "experience"}],
                    "totals": self.manifest["totals"]}
        for row in self.experiences:
            if row["id"] == target:
                return {"material": row, "instruction": "Read the topic for its actionable preferences, evidence and exceptions."}
        for group in ("entries", "domain_references", "guides", "model_experience"):
            for row in self.manifest.get(group, []):
                if row["id"] == target:
                    return {"material": row, "instruction": "Read the page for its substantive explanation, complete material, and original-source links."}
        raise ValueError("Unknown browse ID")

    def search(self, query, limit=8):
        terms = set(re.findall(r"[a-z0-9]+", query.lower())) - {"the", "a", "an", "and", "or", "to", "for", "of", "in", "how", "what", "with", "is", "can"}
        if not terms:
            raise ValueError("Search needs substantive terms")
        results = []
        for row in self.items.values():
            if row["kind"] == "original_source" or not row["path"].endswith(".md"):
                continue
            text = self.document(row)["text"]
            lines = text.splitlines()
            hits = [(i + 1, line, sum(bool(re.search(r"\b" + re.escape(t) + r"\b", line.lower())) for t in terms)) for i, line in enumerate(lines)]
            hits = sorted((h for h in hits if h[2]), key=lambda h: h[2], reverse=True)
            if hits:
                score = sum(t in row["title"].lower() for t in terms) * 4 + hits[0][2] + len({t for t in terms if t in text.lower()})
                results.append({**row, "score": score, "matches": [{"line": n, "excerpt": line[:650], "excerpt_shortened": len(line) > 650} for n, line, _ in hits[:2]]})
        return {"query": query, "method": "lexical full-text search with title weighting; candidates for model judgment", "matches": sorted(results, key=lambda x: x["score"], reverse=True)[:max(1, min(int(limit), 15))]}
