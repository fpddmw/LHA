"""Create an immutable local-media handoff for independent evaluation, without judging."""
import argparse,hashlib,json,sys
from datetime import datetime,timezone
from pathlib import Path

import av

BASE=Path(__file__).resolve().parent
ROOT=BASE.parents[2]
sys.path.insert(0,str(ROOT/'src'))
from evaluation.protocol import validate_card


def load(p):return json.loads(p.read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def relative(p):return p.relative_to(ROOT).as_posix()
def save(p,v):
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--card-map',type=Path,help='Optional evaluator-owned task_id to frozen-card path map')
    args=parser.parse_args()
    tasks={t['task_id']:t for t in load(BASE/'tasks.json')}
    cards=load(args.card_map) if args.card_map else {}
    for p in (ROOT/'examples/evaluation').glob('*.card.json'):
        c=load(p)
        if c['task_id'] in tasks and c['task_id'] not in cards:cards[c['task_id']]=relative(p)
    for task_id,path in cards.items():
        card=validate_card(load(ROOT/path));task=tasks[task_id]
        assert card['source_sha256']==task['source_sha256'] and card['requirement']==task['user_requirement']
    # The baseline recorded actual source indices used by the matched renderer setup.
    mapping_reference={c['case_id']:c for c in load(ROOT/'out/prompt_probe/20261029_ditto/cases.json')['cases']}
    manifests={m:load(BASE/('render_'+m)/'cases.json') for m in ['bernini','ditto']}
    ready=[];all_rows=[]
    for model,spec in manifests.items():
        for case in spec['cases']:
            directory=BASE/('render_'+model)/case['case_id'];result_path=directory/'result.json'
            result=load(result_path) if result_path.exists() else {}
            verified=directory/'local-verification.json'
            available=result.get('status')=='complete' and verified.exists() and (directory/'native.mp4').exists()
            row={'case_id':model+'__'+case['case_id'],'model':model,'method':model+'__'+case['ablation_arm'],
                 'task_id':case['task_id'],'source_id':case['sample_id'],'track':case['task_prompt_kind'],
                 'arm':case['ablation_arm'],'seed':case['seed'],'split':'development','development_exposed':True,
                 'user_requirement':case['user_requirement'],'source_video':case['source_video'],
                 'source_sha256':case['source_video_sha256'],'output_video':relative(directory/'native.mp4'),
                 'card':cards.get(case['task_id']),
                 'status':'available' if available else 'pending_local_verification' if result.get('status')=='complete' else result.get('status','pending_generation'),
                 'snapshot_sha256':case['ablation_snapshot_sha256'],
                 'input_record':relative(directory/'input.json'),'result_record':relative(result_path),
                 'planning_run':case['planner_run'],'generation_seconds':result.get('elapsed_seconds')}
            if available:
                checked=load(verified)['decoded']['native.mp4']
                assert sha(directory/'native.mp4')==checked['sha256']
                assert checked['frames']==case['num_frames'] and abs(checked['fps']-case['fps'])<.001
                actual=load(directory/'input.json')
                for key in ['prompt','seed','source_video_sha256','ablation_arm','ablation_snapshot_sha256','planner_prompt_sha256']:
                    assert actual[key]==case[key]
                row.update(output_sha256=checked['sha256'],frames=checked['frames'],fps=checked['fps'],
                    width=checked['width'],height=checked['height'],duration_seconds=checked['frames']/checked['fps'])
                ready.append(row)
            all_rows.append(row)
    assert len(all_rows)==16
    if not ready:
        print(json.dumps({'status':'no_verified_ablation_outputs_yet','planned':16}))
        return
    stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ');destination=BASE/'handoff'/stamp
    destination.mkdir(parents=True,exist_ok=False)
    source_times={}
    for row in ready:
        source=ROOT/row['source_video']
        if row['source_id'] not in source_times:
            assert sha(source)==row['source_sha256']
            with av.open(str(source)) as container:
                times=[float(f.pts*f.time_base) for f in container.decode(video=0)]
            source_times[row['source_id']]=[t-times[0] for t in times]
        original=mapping_reference[row['task_id']]
        indices=original['conditioning_source_indices'];assert len(indices)==row['frames']
        mapping=destination/'mappings'/(row['case_id']+'.json')
        save(mapping,{'source_sha256':row['source_sha256'],'output_sha256':row['output_sha256'],
             'source_times_seconds':[source_times[row['source_id']][i] for i in indices]})
        row['mapping']=relative(mapping)
    source_pairs={r['case_id']:r for r in ready}
    all_rows=[source_pairs.get(row['case_id'],row) for row in all_rows]
    save(destination/'available_cases.json',{'cases':ready})
    save(destination/'all_planned_cases.json',{'cases':all_rows})
    save(destination/'tasks.json',list(tasks.values()))
    minimal=lambda row:{k:row[k] for k in ['case_id','method','seed','card','output_video','mapping']}
    save(destination/'evaluate.ready-frozen-cards.json',{'cases':[minimal(r) for r in ready if r['card']]})
    save(destination/'source-provenance.json',{'frozen':load(BASE/'freeze.json'),
        'knowledge_use_audit':load(BASE/'knowledge-use-audit.json'),
        'runtime_loader_adapters':{m:s.get('runtime_loader_adapter') for m,s in manifests.items()},
        'infrastructure_interruption_records':[relative(p) for p in BASE.glob('render_*/infrastructure-interruptions/*/interruption.json')],
        'role':'Process provenance only; do not include it in independent final judge prompts.'})
    summary={'snapshot_utc':stamp,'planned':16,'available':len(ready),
        'available_by_renderer':{m:sum(r['model']==m for r in ready) for m in ['bernini','ditto']},
        'missing_cards':[tid for tid in tasks if tid not in cards],'formal_judge_called':False,
        'native_media_only':True,'version_snapshot_sha256':load(BASE/'freeze.json')['snapshot_sha256']}
    save(destination/'summary.json',summary)
    text=['# 知识库消融本地评价交接','',f'固定快照 UTC：{stamp}；预定16条，当前已有{len(ready)}条完整回传并校验。',
        '视频引用仓库内本地文件，不需要重新连接服务器。all_planned_cases保留所有预定条件；未生成或未回传项明确保留，不在当前阶段记成生成失败。',
        'available_cases含实际native路径、SHA、任务要求、源视频和每输出帧对应原片PTS的mapping；评价入口evaluate.ready-frozen-cards只含已有冻结卡的可用子集，不能当作最终全量统计清单。',
        '原始任务共4项：041短、027短、024长、fewshot004长。所有题目已开发暴露，同一原片和原始要求在full/no及两模型间一致；seed42。普通题101@20fps=5.05秒，乒乓球133@30fps≈4.43秒。',
        '缺少冻结卡的任务交评价session完成：'+', '.join(summary['missing_cards'])+'。可用--card-map传入评价会话审定卡的路径映射；本脚本不代写语义标签。',
        'source-provenance仅供过程核对，包含生成/知识审计。最终独立judge只读原始要求、冻结卡及源/输出证据，不读取过程提示词、方法身份或历史critic。',
        '完整知识组自动注入11371字符阅读手册和入口元数据；8份规划均未主动检索/读取知识。按知识可用性与自动手册注入的组合处理解释，不能据此声称已经单独验证主动检索收益。',
        '本目录只做媒体与对应关系交接，没有进行正式评分。后续结果生成新快照，保留本目录不变。','']
    (destination/'README.md').write_text('\n\n'.join(text),encoding='utf-8')
    save(BASE/'handoff/latest.json',{'snapshot':relative(destination),'summary':summary})
    print(json.dumps({'snapshot':relative(destination),**summary}),flush=True)


if __name__=='__main__':main()
