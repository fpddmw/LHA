"""One clean planning run per arm and task, without output feedback or rendering."""
import difflib,json,os,sys,traceback
from pathlib import Path

BASE=Path(__file__).resolve().parent
ROOT=BASE.parents[2]
SNAPSHOT=BASE/'snapshot'
sys.path[:0]=[str(BASE),str(SNAPSHOT/'src'),str(ROOT/'out/planner_harness/_deps'),
             r'C:/Users/17919/AppData/Local/Temp/lha-semantic-probe-deps']
os.environ['LOW_HIGH_CODEX_BIN']=r'C:/Users/17919/AppData/Local/OpenAI/Codex/bin/08d187884f2330d1/codex.exe'
os.environ['LOW_HIGH_AGENT_CODEX_PLANNER_MODEL']='gpt-6.1-sol'
os.environ['LOW_HIGH_AGENT_CODEX_PLANNER_REASONING_EFFORT']='xhigh'
os.environ['LOW_HIGH_AGENT_CODEX_ATTEMPTS']='2'
os.environ['LOW_HIGH_AGENT_CODEX_TIMEOUT']='1800'
from planner_harness.common import save,sha,stamp
from planner_harness.lock import RunLock
from vlm.codex_vlm import CodexVisionModel
from ablation_adapter import AblationHarness,audit_run,no_knowledge_operations


def main():
    freeze=json.loads((BASE/'freeze.json').read_text(encoding='utf-8'))
    for item in freeze['files']:assert sha(SNAPSHOT/item['path'])==item['sha256'],item['path']
    tasks=json.loads((BASE/'tasks.json').read_text(encoding='utf-8'))
    status=json.loads((BASE/'status.json').read_text(encoding='utf-8'))
    operations=(SNAPSHOT/'src/planner_harness/OPERATIONS.md').read_text(encoding='utf-8')
    full_system=operations+'\n\n# Current knowledge reading manual\n\n'+(SNAPSHOT/'knowledge/READING.md').read_text(encoding='utf-8')
    audit=BASE/'context-policy';audit.mkdir(exist_ok=True)
    (audit/'full_knowledge.system.txt').write_text(full_system,encoding='utf-8')
    (audit/'no_knowledge.system.txt').write_text(no_knowledge_operations(),encoding='utf-8')
    (audit/'system-diff.patch').write_text(''.join(difflib.unified_diff(full_system.splitlines(True),no_knowledge_operations().splitlines(True),fromfile='full_knowledge',tofile='no_knowledge')),encoding='utf-8')
    save(audit/'policy.json',{'frozen_snapshot_sha256':freeze['snapshot_sha256'],
        'shared':{'source_observation':'frozen Video + observe/crop','target':'unspecified','mode':'plan',
                  'max_turns':24,'max_context_chars':180000,'model':'gpt-6.1-sol','reasoning':'xhigh',
                  'imported_videos':False,'output_feedback':False,'render_prompt_postprocessing':False},
        'full_knowledge':'Unmodified frozen OPERATIONS and READING, normal indexed knowledge access.',
        'no_knowledge':'No knowledge manual, map, entrances, receipts, source material or references; material tools denied before dispatch. Empty per-run knowledge snapshot. Generic run/observation/output instructions retained.',
        'transport':'Frozen CodexVisionModel uses a clean ephemeral directory, ignores user config/rules, disables host tools/apps/delegation/web, and sends only explicit system/context/source images.',
        'adapter_sha256':sha(BASE/'ablation_adapter.py'),'runner_sha256':sha(Path(__file__))})
    sequence=[]
    for index,task in enumerate(tasks):
        arms=['full_knowledge','no_knowledge'] if index%2==0 else ['no_knowledge','full_knowledge']
        for arm in arms:sequence.append((task,arm))
    for index,(task,arm) in enumerate(sequence,1):
        run_id=f'p{index:02d}';output=BASE/'planning'/run_id
        row=next(r for r in status['runs'] if r['task_id']==task['task_id'] and r['arm']==arm)
        row.update(run_id=run_id,planning_path=str(output.relative_to(ROOT)).replace('\\','/'))
        status.update(status='planning',updated_at=stamp());save(BASE/'status.json',status)
        os.environ['LOW_HIGH_VLM_AUDIT_LOG']=str(output/'model-usage.jsonl')
        print(json.dumps({'stage':'planning','run_id':run_id,'task_id':task['task_id'],'arm':arm}),flush=True)
        try:
            with RunLock(output):
                model=CodexVisionModel(role='planner');harness=AblationHarness(output,model,arm=arm)
                if (output/'state.json').exists():
                    prior=json.loads((output/'state.json').read_text(encoding='utf-8'))
                    if prior['status']=='complete':state=prior
                    elif prior['status'] in ['budget_exhausted','context_limit']:state=prior
                    else:state=harness.resume()
                else:
                    state=harness.start(str(SNAPSHOT/task['source_video']),task['user_requirement'],
                        target='unspecified',max_turns=24,max_context_chars=180000,mode='plan',max_generations=1)
            audit_result=audit_run(output,arm)
            row.update(planning_status=state['status'],attempts=state['attempts'],reads=audit_result['read_count'])
            if state['status']=='complete':
                handoff=json.loads((output/'handoff.json').read_text(encoding='utf-8'))
                assert handoff['source']['sha256']==task['source_sha256']
                assert handoff['prompt']==(output/'prompt.txt').read_text(encoding='utf-8')
                assert handoff['prompt_sha256']==sha(output/'prompt.txt')
                row.update(prompt_sha256=handoff['prompt_sha256'],renders={'bernini':'waiting_for_gpu','ditto':'waiting_for_gpu'})
        except Exception as exc:
            row.update(planning_status='error',error=repr(exc));traceback.print_exc()
        save(BASE/'status.json',status)
        print(json.dumps(row,ensure_ascii=False),flush=True)
    status.update(status='planning_finished',updated_at=stamp());save(BASE/'status.json',status)


if __name__=='__main__':main()
