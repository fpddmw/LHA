"""Export exact audited planning handoffs to the two validated renderer schemas."""
import copy,hashlib,json,sys
from pathlib import Path
BASE=Path(__file__).resolve().parent
ROOT=BASE.parents[2]
sys.path.insert(0,str(ROOT/'scripts/deploy'))
from run_prompt_probe import digest,save


def main():
    state=json.loads((BASE/'status.json').read_text(encoding='utf-8'))
    freeze=json.loads((BASE/'freeze.json').read_text(encoding='utf-8'))
    tasks={t['task_id']:t for t in json.loads((BASE/'tasks.json').read_text(encoding='utf-8'))}
    expected=[r['task_id']+'__'+r['arm'] for r in state['runs']]
    terminal=all(r['planning_status'] not in ['pending','running'] for r in state['runs'])
    for model in ['bernini','ditto']:
        baseline=json.loads((ROOT/f'out/prompt_probe/20261029_{model}/cases.json').read_text(encoding='utf-8'))
        spec={k:copy.deepcopy(v) for k,v in baseline.items() if k!='cases'}
        spec.update(purpose='Frozen-version paired knowledge-availability ablation',expected_cases=8,
            expected_case_ids=expected,planning_terminal=terminal,cases=[],planning_failures=[],
            ablation_snapshot_sha256=freeze['snapshot_sha256'],
            renderer_runner_sha256=digest(ROOT/'scripts/deploy'/('run_prompt_probe.py' if model=='bernini' else 'run_ditto_prompt_probe.py')),
            source_observation_equal=True,formal_evaluation_owner='separate session',submitted_prompt_sha256={})
        for row in state['runs']:
            task=tasks[row['task_id']];cid=row['task_id']+'__'+row['arm']
            if row['planning_status']!='complete':
                if terminal:spec['planning_failures'].append({'case_id':cid,'status':row['planning_status'],'error':row.get('error')})
                continue
            plan=ROOT/row['planning_path'];handoff=json.loads((plan/'handoff.json').read_text(encoding='utf-8'))
            audit=json.loads((plan/'model-visible-audit.json').read_text(encoding='utf-8'))
            planner_state=json.loads((plan/'state.json').read_text(encoding='utf-8'))
            prompt=(plan/'prompt.txt').read_text(encoding='utf-8')
            assert prompt==handoff['prompt']==planner_state['proposal']['prompt']
            assert handoff['validation']['accepted'] and digest(plan/'prompt.txt')==row['prompt_sha256']==handoff['prompt_sha256']
            assert handoff['source']['sha256']==task['source_sha256'] and planner_state['request']['text']==task['user_requirement']
            if row['arm']=='no_knowledge':assert audit['no_knowledge_boundary_passed'] and audit['read_count']==0
            original=next(c for c in baseline['cases'] if c['case_id']==task['task_id'])
            assert original['prompt']==task['user_requirement'] and digest(ROOT/original['source_video'])==task['source_sha256']
            case=copy.deepcopy(original)
            case.update(case_id=cid,condition=row['arm'],prompt=prompt,user_requirement=task['user_requirement'],
                task_id=task['task_id'],task_prompt_kind=task['track'],ablation_arm=row['arm'],
                planner_run=row['planning_path'],planner_prompt_sha256=handoff['prompt_sha256'],
                planner_handoff_sha256=digest(plan/'handoff.json'),ablation_snapshot_sha256=freeze['snapshot_sha256'],
                ablation_adapter_sha256=digest(BASE/'ablation_adapter.py'),
                planner_model='gpt-6.1-sol',planner_reasoning_effort='xhigh',planner_target_model='unspecified',
                model_visible_audit_sha256=digest(plan/'model-visible-audit.json'),
                one_generation_opportunity=True,seed=42)
            spec['cases'].append(case)
            spec['submitted_prompt_sha256'][cid]=hashlib.sha256(prompt.encode('utf-8')).hexdigest()
        folder=BASE/('render_'+model);folder.mkdir(exist_ok=True)
        target=folder/'cases.json'
        if target.exists():
            prior=json.loads(target.read_text(encoding='utf-8'))
            if prior.get('runtime_loader_adapter'):
                spec['runtime_loader_adapter']=prior['runtime_loader_adapter']
            current={c['case_id']:c for c in spec['cases']}
            assert all(current.get(c['case_id'])==c for c in prior['cases']), 'Published prompts cannot change'
        save(target,spec)
        print(json.dumps({'renderer':model,'ready':len(spec['cases']),'expected':8,'planning_terminal':terminal}),flush=True)


if __name__=='__main__':main()
